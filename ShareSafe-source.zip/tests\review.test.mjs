import test from 'node:test';
import assert from 'node:assert/strict';
import {privateMatches,mergeFindings} from '../dist/privacy.js';
import {drawComposite} from '../dist/core.js';
test('two OCR passes merge nearby same-kind covers outward without crossing unrelated rows',()=>{
 const first={id:'a',kind:'name',x:20,y:30,w:80,h:20,review:true},second={id:'b',kind:'name',x:18,y:29,w:86,h:22};
 const input=structuredClone([[first],[second,{...second,y:90}]]),result=mergeFindings(input);
 assert.equal(result.length,2);assert.deepEqual([result[0].x,result[0].y,result[0].w,result[0].h],[18,29,86,22]);assert.equal(input[0][0].x,20);
});
test('config secrets, terminal identities and work context survive common OCR spacing',()=>{
 for(const text of ['jwt_secret: xoxb-abcdefgh12345678','SHA256:Abcd01234567890xyzABCDEFG','password: EXAMPLE_12345'])assert.ok(privateMatches(text).some(m=>m.kind==='secret'),text);
 for(const text of ['host: db.example. com','# marketing','acme-labs / private-app'])assert.ok(privateMatches(text).some(m=>m.kind==='work'&&m.review),text);
 assert.ok(privateMatches('/Users/fictional/.ssh/id_ed25519').some(m=>m.kind==='personal'));
 assert.ok(privateMatches('fictional@dev-machine').some(m=>m.kind==='username'));
 assert.equal(privateMatches('port: 5432').length,0);
});
test('blur without a supported canvas filter falls back to opaque black',()=>{
 const old=globalThis.OffscreenCanvas,calls=[];
 globalThis.OffscreenCanvas=class{getContext(){return {};}};
 try {const ctx={save(){},restore(){},drawImage(){},fillRect(x,y,w,h){calls.push({x,y,w,h,color:this.fillStyle,alpha:this.globalAlpha});}};
 drawComposite(ctx,{},[{type:'redact',style:'blur',x:1.2,y:3.4,w:20,h:15}],100,100);
 assert.deepEqual(calls.at(-1),{x:1,y:3,w:21,h:16,color:'#000000',alpha:1});
 }finally{if(old===undefined)delete globalThis.OffscreenCanvas;else globalThis.OffscreenCanvas=old;}
});

test('an OCR space after @ keeps lowercase usernames in the username filter',()=>{assert.ok(privateMatches('@ farah').some(m=>m.kind==='username'&&m.start===0&&m.end===7));assert.ok(!privateMatches('token',{people:['token']}).some(m=>m.kind==='name'));});

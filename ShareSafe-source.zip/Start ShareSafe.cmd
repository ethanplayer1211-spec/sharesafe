@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo ShareSafe needs Node.js 20 or later. Install Node.js, then open this file again.
  pause
  exit /b 1
)
echo Open http://127.0.0.1:4173/ in your browser.
echo Keep this window open while using ShareSafe. Press Ctrl+C to stop.
node server.mjs
if errorlevel 1 pause

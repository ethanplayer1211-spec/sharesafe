import { createWorker } from 'tesseract.js';
import { readFile,writeFile } from 'node:fs/promises';
import { resolve,basename } from 'node:path';
import nlp from 'compromise';
import { decode } from './verify-ocr-export.mjs';
import { pngRGBA } from './png-encode.mjs';
import { findingsFromOCR,ocrSegments } from '../dist/privacy.js';
import { normalizeTextContrast } from '../dist/ocr.js';
import { analyzeChat,chatAvatars,chatDividers } from '../dist/chat.js';
import { detectPictureRegions } from '../dist/pictures.js';
const root='.runtime/qa/random-five',selection=JSON.parse(await readFile(root+'/selection.json','utf8'));
const gold=(await readFile(root+'/annotations.jsonl','utf8')).trim().split('\n').map(JSON.parse);
const worker=await createWorker('eng',1,{langPath:resolve('node_modules/@tesseract.js-data/eng/4.0.0_best_int'),cacheMethod:'none'});
const reports=[];
try {
 await worker.setParameters({tessedit_pageseg_mode:'11',user_defined_dpi:'150'});
 for(const path of selection.selected){
  const file=basename(path),image=await decode(root+'/'+file),rgba=new Uint8ClampedArray(image.width*image.height*4);
  for(let i=0;i<image.width*image.height;i++){rgba.set(image.pixels.subarray(i*image.channels,i*image.channels+3),i*4);rgba[i*4+3]=255;}
  const normalized=({data:new Uint8ClampedArray(rgba),width:image.width,height:image.height});
  const {data}=await worker.recognize(pngRGBA(normalized.data,image.width,image.height),{}, {blocks:true});
  const rows=ocrSegments(data),pixels={width:image.width,height:image.height,data:rgba};
  const text=findingsFromOCR(data,image.width,image.height,1,{findPeople:value=>nlp(value).people().out('array')});
  const avatars=chatAvatars(pixels,rows),dividers=chatDividers(pixels),chat=analyzeChat(data,image.width,image.height,1,{avatars,dividers});
  const pictures=detectPictureRegions(pixels,image.width,image.height,{textBoxes:rows.map(r=>({x:r.x,y:r.y,w:r.w,h:r.h})),peopleBoxes:text.filter(f=>f.kind==='name')});
  const findings=[...text,...chat.findings,...pictures,...(chat.avatars||[])];
  const expected=gold.find(g=>g.id===file.replace('.png',''));
  const result={file,width:image.width,height:image.height,data,findings,expected,chatDetected:chat.detected};
  await writeFile(root+'/'+file.replace('.png','-scan.json'),JSON.stringify(result));
  const regions=expected.spans.map(s=>{const [x,y,w,h]=s.bbox;return {label:s.label,text:s.text,matched:findings.filter(f=>f.x<x+w&&f.x+f.w>x&&f.y<y+h&&f.y+f.h>y).map(f=>f.kind)};});
  reports.push({file,regions,findings:findings.length,ocr:data.text});console.log(JSON.stringify(reports.at(-1)));
 }
 await writeFile(root+'/baseline.json',JSON.stringify(reports,null,2));
} finally {await worker.terminate();}




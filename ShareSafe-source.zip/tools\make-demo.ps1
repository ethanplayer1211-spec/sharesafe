$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$projectPath = Split-Path $PSScriptRoot -Parent
$framePath = Join-Path $projectPath '.runtime\demo-frames'
$mediaPath = Join-Path $projectPath 'docs\media'
New-Item -ItemType Directory -Path $framePath -Force | Out-Null
$scenes = @(
  @{Title="ShareSafe`nScreenshot privacy";Bullets=@('Find private details on your device.','Preview covers before applying.','Keep the rest of the screenshot.');Image='dm-black-preview.jpg';Seconds=7},
  @{Title="Choose what`nto hide";Bullets=@('Names, handles, messages and photos.','Birthdays, personal fields and secrets.','Twelve filters and your own words.');Image='filters-v14.jpg';Seconds=7},
  @{Title="Plain black`nor strong blur";Bullets=@('Black replaces the covered pixels.','One style switch updates all covers.','Export keeps the original resolution.');Image='dm-black-export.png';Seconds=7},
  @{Title="Preview`nthe blur";Bullets=@('Blur is rendered into the PNG.','It can retain visual clues.','Choose black for stronger concealment.');Image='dm-blur-export.png';Seconds=7},
  @{Title="Five random`nscreens tested";Bullets=@('Arc, Slack, GitHub, Terminal and Cursor.','Selected before testing; fictional data.','Black and blur exports checked.');Image='five-tested.png';Seconds=8},
  @{Title="Review`nstill matters";Bullets=@('Detection can miss an icon or path.','Two test cases needed manual covers.','Reject incorrect suggestions.');Image='github-review-detail.png';Seconds=8},
  @{Title="Check once.`nThen download.";Bullets=@('Preview can be cancelled without edits.','Applied covers support undo and redo.','The PNG has no source or history attached.');Image='cursor-black-export.png';Seconds=7},
  @{Title="Runs on`nyour device";Bullets=@('Bundled English OCR and name recognition.','No account, API key or image upload.','Tesseract and Compromise.','Built with assistance from OpenAI Codex.');Image='dm-black-preview.jpg';Seconds=9}
)
$ink=[System.Drawing.SolidBrush]::new([System.Drawing.ColorTranslator]::FromHtml('#282c2a'))
$muted=[System.Drawing.SolidBrush]::new([System.Drawing.ColorTranslator]::FromHtml('#6e7864'))
$coral=[System.Drawing.SolidBrush]::new([System.Drawing.ColorTranslator]::FromHtml('#e66c4f'))
$white=[System.Drawing.SolidBrush]::new([System.Drawing.Color]::White)
$brandFont=[System.Drawing.Font]::new('Segoe UI',33,[System.Drawing.FontStyle]::Bold,[System.Drawing.GraphicsUnit]::Pixel)
$titleFont=[System.Drawing.Font]::new('Segoe UI',61,[System.Drawing.FontStyle]::Bold,[System.Drawing.GraphicsUnit]::Pixel)
$bodyFont=[System.Drawing.Font]::new('Segoe UI',28,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Pixel)
$smallFont=[System.Drawing.Font]::new('Segoe UI',20,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Pixel)
$border=[System.Drawing.Pen]::new([System.Drawing.ColorTranslator]::FromHtml('#dfe0d7'))
$concat=[System.Collections.Generic.List[string]]::new()
try {
  for($index=0;$index -lt $scenes.Count;$index++){
    $scene=$scenes[$index];$bitmap=[System.Drawing.Bitmap]::new(1920,1080)
    $g=[System.Drawing.Graphics]::FromImage($bitmap)
    $g.Clear([System.Drawing.ColorTranslator]::FromHtml('#f6f5f1'))
    $g.SmoothingMode=[System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.TextRenderingHint=[System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit
    $g.InterpolationMode=[System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    try {
      $g.FillRectangle($coral,80,58,18,18);$g.FillRectangle($coral,102,58,18,18)
      $g.FillRectangle($coral,80,80,18,18);$g.FillRectangle($ink,102,80,18,18)
      $g.DrawString('sharesafe.',$brandFont,$ink,137,53)
      $g.DrawString(('SHARESAFE   /   {0:00} OF {1:00}' -f ($index+1),$scenes.Count),$smallFont,$muted,1500,65)
      $g.DrawString($scene.Title,$titleFont,$ink,[System.Drawing.RectangleF]::new(80,230,650,180))
      $bulletY=475
      foreach($bullet in $scene.Bullets){
        $g.FillEllipse($coral,84,$bulletY+14,7,7)
        $g.DrawString($bullet,$bodyFont,$muted,[System.Drawing.RectangleF]::new(109,$bulletY,600,80))
        $bulletY+=90
      }
      $image=[System.Drawing.Image]::FromFile((Join-Path $mediaPath $scene.Image))
      try {
        $scale=[Math]::Min(1040.0/$image.Width,770.0/$image.Height)
        $w=[int]($image.Width*$scale);$h=[int]($image.Height*$scale)
        $x=790+[int]((1040-$w)/2);$y=190+[int]((770-$h)/2)
        $g.FillRectangle($white,$x-1,$y-1,$w+2,$h+2)
        $g.DrawImage($image,[System.Drawing.Rectangle]::new($x,$y,$w,$h));$g.DrawRectangle($border,$x-1,$y-1,$w+2,$h+2)
      } finally { $image.Dispose() }
      $g.DrawString('Captioned walkthrough using actual editor captures and exported PNGs. Example data is fictional.',$smallFont,$muted,80,980)
      $g.DrawString('Test images: Louis Beaumont / ScreenLeak (CC BY 4.0), modified with ShareSafe.',$smallFont,$muted,80,1010)
      $frameName='scene-{0:00}.png' -f $index
      $bitmap.Save((Join-Path $framePath $frameName),[System.Drawing.Imaging.ImageFormat]::Png)
      $concat.Add("file '$frameName'");$concat.Add("duration $($scene.Seconds)")
    } finally { $g.Dispose();$bitmap.Dispose() }
  }
  $concat.Add(("file 'scene-{0:00}.png'" -f ($scenes.Count-1)))
  [IO.File]::WriteAllLines((Join-Path $framePath 'scenes.txt'),$concat,[Text.UTF8Encoding]::new($false))
} finally { foreach($r in @($ink,$muted,$coral,$white,$brandFont,$titleFont,$bodyFont,$smallFont,$border)){$r.Dispose()} }
$duration=0;foreach($scene in $scenes){$duration+=$scene.Seconds}
& ffmpeg -hide_banner -loglevel warning -y -f concat -safe 0 -i (Join-Path $framePath 'scenes.txt') -t $duration -vf 'fps=30,format=yuv420p' -c:v libx264 -preset medium -crf 19 -movflags +faststart -an (Join-Path $mediaPath 'ShareSafe-demo.mp4')
if($LASTEXITCODE -ne 0){throw 'Video rendering failed.'}
& ffprobe -v error -show_entries format=duration,size -show_entries stream=codec_name,width,height -of json (Join-Path $mediaPath 'ShareSafe-demo.mp4')


import { readFile, mkdir, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { Script } from 'node:vm';

const normalize = text => text.replace(/\r\n?/g,'\n');
const html = normalize(await readFile('src/editor.html','utf8'));
const css = normalize(await readFile('dist/style.css','utf8'));
const core = normalize(await readFile('dist/core.js','utf8')).replace(/^export /gm,'');
const example = 'data:image/svg+xml;base64,' + (await readFile('dist/example.svg')).toString('base64');
const favicon = 'data:image/svg+xml;base64,' + (await readFile('dist/favicon.svg')).toString('base64');
const app = normalize(await readFile('dist/app.js','utf8')).replace(/^import[\s\S]+?from '\.\/core\.js';\s*/,'')
  .replaceAll("'./example.svg'",JSON.stringify(example));
// A classic script at the end of the body also works under file://. Keep all
// declarations inside a closure instead of colliding with browser globals.
const script = `(() => {\n'use strict';\n${core}\n${app}\n})();`;
new Script(script); // The portable bundle must not retain imports or exports.
const hash = text => createHash('sha256').update(text).digest('base64');
const output = html.replace('href="./favicon.svg"',`href="${favicon}"`)
  .replace('<link rel="stylesheet" href="./style.css">',()=>`<style>${css}</style>`)
  .replace('<script type="module" src="./app.js"></script>','')
  .replace('</body>',()=>`<script>${script}</script>\n</body>`)
  .replace("script-src 'self'; style-src 'self';",`script-src 'sha256-${hash(script)}'; style-src 'sha256-${hash(css)}';`)
  .replace('href="./" aria-label="ShareSafe home"','href="#" aria-label="ShareSafe home"');
await mkdir('release',{recursive:true});
await writeFile('release/ShareSafe.html',output);
await writeFile('dist/index.html',output);
await writeFile('ShareSafe.html',output);
console.log(JSON.stringify({files:['ShareSafe.html','dist/index.html','release/ShareSafe.html'],bytes:Buffer.byteLength(output),externalAssets:0,inlineCodeValidated:true}));

import { readFile, mkdir, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { Script } from 'node:vm';
import './build-notices.mjs';

const normalize = text => text.replace(/\r\n?/g,'\n');
const html = normalize(await readFile('src/editor.html','utf8'));
const notices = normalize(await readFile('THIRD_PARTY_NOTICES.txt','utf8'));
const css = normalize(await readFile('dist/style.css','utf8'));
const core = normalize(await readFile('dist/core.js','utf8')).replace(/^export /gm,'');
const privacy = normalize(await readFile('dist/privacy.js','utf8')).replace(/^export /gm,'');
const ocr = normalize(await readFile('dist/ocr.js','utf8')).replace(/^export /gm,'');
const pictures = normalize(await readFile('dist/pictures.js','utf8')).replace(/^export /gm,'');
const names = normalize(await readFile('node_modules/compromise/builds/compromise.js','utf8')).replaceAll('</script','<\\/script');
const workerCore = await readFile('node_modules/tesseract.js-core/tesseract-core-simd-lstm.wasm.js','utf8');
const workerAdapter = await readFile('node_modules/tesseract.js/dist/worker.min.js','utf8');
// Preload the bundled core into the worker. Tesseract never calls importScripts
// or fetch: its model is supplied directly as bytes with cacheMethod: 'none'.
const workerSource = `${workerCore}\nself.TesseractCore = TesseractCore;\n${workerAdapter}`;
const model = (await readFile('node_modules/@tesseract.js-data/eng/4.0.0_best_int/eng.traineddata.gz')).toString('base64');
const literal = value => JSON.stringify(value).replaceAll('<','\\u003c');
const ocrAssets = `const OCR_WORKER_SOURCE = ${literal(workerSource)};\nconst OCR_ENGLISH_BASE64 = ${literal(model)};`;
const example = 'data:image/svg+xml;base64,' + (await readFile('dist/example.svg')).toString('base64');
const profile = 'data:image/png;base64,' + (await readFile('dist/profile-example.png')).toString('base64');
const favicon = 'data:image/svg+xml;base64,' + (await readFile('dist/favicon.svg')).toString('base64');
const app = normalize(await readFile('dist/app.js','utf8')).replace(/^import[\s\S]+?from '\.\/[^']+\.js';\s*/gm,'')
  .replaceAll("'./example.svg'",JSON.stringify(example))
  .replaceAll("'./profile-example.png'",JSON.stringify(profile));
// A classic script at the end of the body also works under file://. Keep all
// declarations inside a closure instead of colliding with browser globals.
const script = `(() => {\n'use strict';\n${names}\n${core}\n${privacy}\n${pictures}\n${ocrAssets}\n${ocr}\n${app}\n})();`;
new Script(script); // The portable bundle must not retain imports or exports.
const hash = text => createHash('sha256').update(text).digest('base64');
const output = html.replace('href="./favicon.svg"',`href="${favicon}"`)
  .replace('</head>',()=>`<!--\n${notices.replaceAll('--','- -')}\n-->\n</head>`)
  .replace('<link rel="stylesheet" href="./style.css">',()=>`<style>${css}</style>`)
  .replace('<script type="module" src="./app.js"></script>','')
  .replace('</body>',()=>`<script>${script}</script>\n</body>`)
  .replace("script-src 'self'; style-src 'self';",`script-src 'sha256-${hash(script)}' 'wasm-unsafe-eval'; style-src 'sha256-${hash(css)}';`)
  .replace('href="./" aria-label="ShareSafe home"','href="#" aria-label="ShareSafe home"');
await mkdir('release',{recursive:true});
await writeFile('release/ShareSafe.html',output);
await writeFile('dist/index.html',output);
await writeFile('ShareSafe.html',output);
console.log(JSON.stringify({files:['ShareSafe.html','dist/index.html','release/ShareSafe.html'],bytes:Buffer.byteLength(output),externalAssets:0,inlineCodeValidated:true}));

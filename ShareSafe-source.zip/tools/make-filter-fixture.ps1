$ErrorActionPreference='Stop'
Set-Location -LiteralPath (Split-Path $PSScriptRoot -Parent)
Add-Type -AssemblyName System.Drawing
$bitmap=[Drawing.Bitmap]::new(1360,860)
$g=[Drawing.Graphics]::FromImage($bitmap); $g.Clear([Drawing.Color]::White)
$g.TextRenderingHint=[Drawing.Text.TextRenderingHint]::AntiAliasGridFit
$font=[Drawing.Font]::new('Arial',24,[Drawing.FontStyle]::Regular,[Drawing.GraphicsUnit]::Pixel)
$title=[Drawing.Font]::new('Arial',32,[Drawing.FontStyle]::Bold,[Drawing.GraphicsUnit]::Pixel)
$g.DrawString('Fictional creator profile',$title,[Drawing.Brushes]::Black,40,25)
# An original illustrated avatar; no real personal photo is used.
$avatarBrush=[Drawing.SolidBrush]::new([Drawing.Color]::FromArgb(232,151,106))
$g.FillEllipse($avatarBrush,40,100,80,80)
$g.FillEllipse([Drawing.Brushes]::SaddleBrown,56,108,48,24)
$g.FillEllipse([Drawing.Brushes]::Black,60,136,7,7);$g.FillEllipse([Drawing.Brushes]::Black,88,136,7,7)
$g.DrawArc([Drawing.Pens]::Brown,66,145,30,15,10,160)
$g.DrawString('Alex Morgan',$title,[Drawing.Brushes]::Black,145,120)
$rows=@('Full name: Alex Morgan','Username: @alexcreates','Birthday: 11 December 2008','Address: 120 Oak Street, Example City','Student ID: EX-2048','Email: alex.morgan@example.com','Phone: +1 (415) 555-0123','API key: sk-proj-abcdefghijklmnop1234','Next meeting: 2026-11-16 at 09:41')
for($i=0;$i -lt $rows.Count;$i++){$g.DrawString($rows[$i],$font,[Drawing.Brushes]::Black,40,(220+$i*64))}
# A deterministic, original textured landscape fixture tests picture regions.
$photo=[Drawing.Bitmap]::new(320,220)
$random=[Random]::new(71)
for($y=0;$y -lt 220;$y++){for($x=0;$x -lt 320;$x++){
  $noise=$random.Next(-28,29)
  if($y -lt (105+25*[Math]::Sin($x/47.0))){$r=80+$noise;$green=150+$noise;$b=200+$noise}
  else{$r=60+$noise;$green=110+$noise;$b=75+$noise}
  $photo.SetPixel($x,$y,[Drawing.Color]::FromArgb($r,$green,$b))
}}
$g.DrawImageUnscaled($photo,970,100)
$g.DrawString('A fictional landscape picture',$font,[Drawing.Brushes]::Black,970,338)
New-Item -ItemType Directory -Path '.runtime\qa' -Force | Out-Null
$bitmap.Save((Join-Path $PWD '.runtime\qa\filter-fixture.png'),[Drawing.Imaging.ImageFormat]::Png)
$bitmap.Save((Join-Path $PWD 'dist\profile-example.png'),[Drawing.Imaging.ImageFormat]::Png)
$photo.Dispose();$avatarBrush.Dispose();$title.Dispose();$font.Dispose();$g.Dispose();$bitmap.Dispose()

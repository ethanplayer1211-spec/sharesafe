$ErrorActionPreference='Stop'
Set-Location -LiteralPath (Split-Path $PSScriptRoot -Parent)
Add-Type -AssemblyName System.Drawing
$bitmap=[Drawing.Bitmap]::new(1360,650)
$graphics=[Drawing.Graphics]::FromImage($bitmap)
$graphics.Clear([Drawing.Color]::White)
$graphics.TextRenderingHint=[Drawing.Text.TextRenderingHint]::AntiAliasGridFit
$font=[Drawing.Font]::new('Arial',24,[Drawing.FontStyle]::Regular,[Drawing.GraphicsUnit]::Pixel)
$title=[Drawing.Font]::new('Arial',32,[Drawing.FontStyle]::Bold,[Drawing.GraphicsUnit]::Pixel)
$graphics.DrawString('ShareSafe scan check - fictional details',$title,[Drawing.Brushes]::Black,40,30)
$rows=@('Email: alex.morgan@example.com','Phone: +1 (415) 555-0123','IP address: 192.168.1.24','Payment card: 4111 1111 1111 1111','API key: sk-proj-abcdefghijklmnop1234','Private workspace code: NORTHSTAR-0824-PRIVATE','Next meeting: 2026-11-16 at 09:41')
for($i=0;$i -lt $rows.Count;$i++){$graphics.DrawString($rows[$i],$font,[Drawing.Brushes]::Black,40,(110+$i*68))}
New-Item -ItemType Directory -Path '.runtime\qa' -Force | Out-Null
$bitmap.Save((Join-Path $PWD '.runtime\qa\scan-fixture.png'),[Drawing.Imaging.ImageFormat]::Png)
$title.Dispose(); $font.Dispose(); $graphics.Dispose(); $bitmap.Dispose()

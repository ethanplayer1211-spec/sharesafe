$ErrorActionPreference='Stop'
Set-Location -LiteralPath (Split-Path $PSScriptRoot -Parent)
Add-Type -AssemblyName System.Drawing
$im=[Drawing.Bitmap]::new(1360,860);$g=[Drawing.Graphics]::FromImage($im)
$g.Clear([Drawing.Color]::FromArgb(12,12,12));$g.TextRenderingHint=[Drawing.Text.TextRenderingHint]::AntiAliasGridFit
$resources=[Collections.Generic.List[IDisposable]]::new()
function Brush([string]$hex){$b=[Drawing.SolidBrush]::new([Drawing.ColorTranslator]::FromHtml($hex));$resources.Add($b);return $b}
$white=Brush '#f5f5f5';$muted=Brush '#969696';$panel=Brush '#1d1d1d';$bubble=Brush '#262626';$purple=Brush '#6651dc'
$regular=[Drawing.Font]::new('Arial',18,[Drawing.FontStyle]::Regular,[Drawing.GraphicsUnit]::Pixel);$small=[Drawing.Font]::new('Arial',14,[Drawing.FontStyle]::Regular,[Drawing.GraphicsUnit]::Pixel);$bold=[Drawing.Font]::new('Arial',22,[Drawing.FontStyle]::Bold,[Drawing.GraphicsUnit]::Pixel)
$g.FillRectangle($panel,0,0,1360,54);$g.DrawString('instagram.com/direct/inbox - fictional example',$small,$muted,430,20)
$pen=[Drawing.Pen]::new([Drawing.Color]::FromArgb(45,45,45));$g.DrawLine($pen,76,54,76,860);$g.DrawLine($pen,400,54,400,860);$g.DrawLine($pen,400,140,1360,140)
$g.DrawString('IG',$bold,$white,22,84);$g.DrawString('Messages',$bold,$white,106,86);$g.FillRectangle($panel,102,137,270,38);$g.DrawString('Search',$small,$muted,121,149)
function Avatar([int]$x,[int]$y,[int]$r){
  $back=Brush '#aaaaaa';$hair=Brush '#444444';$face=Brush '#dddddd';
  $g.FillEllipse($back,$x-$r,$y-$r,$r*2,$r*2);$g.FillEllipse($face,$x-$r*.5,$y-$r*.5,$r,$r*1.1);$g.FillEllipse($hair,$x-$r*.6,$y-$r*.75,$r*1.2,$r*.7)
}
Avatar 117 226 22;Avatar 117 314 22;Avatar 117 402 22
$g.DrawString('mira.photos',$regular,$white,157,207);$g.DrawString('Can you send the draft?',$small,$muted,157,237)
$g.DrawString('alexmorgan',$regular,$white,157,295);$g.DrawString('You: see you tomorrow',$small,$muted,157,325)
$g.DrawString('sam_lee',$regular,$white,157,383);$g.DrawString('Shared a private note',$small,$muted,157,413)
Avatar 441 98 20;$g.DrawString('mira.photos',$bold,$white,480,80);$g.DrawString('Active now',$small,$muted,480,109)
$g.DrawString('Today 9:41 AM',$small,$muted,810,167)
Avatar 438 248 14;$g.FillRectangle($bubble,468,208,380,64);$g.DrawString('Can you send the draft tonight?',$regular,$white,484,227)
$g.FillRectangle($purple,920,310,400,90);$g.DrawString('Sure. My home address is',$regular,$white,938,327);$g.DrawString('120 Oak Street, Example City.',$regular,$white,938,358)
Avatar 438 482 14;$g.FillRectangle($bubble,468,430,430,90);$g.DrawString('Thanks! Keep this between us.',$regular,$white,484,447);$g.DrawString('My username is mira.photos',$regular,$white,484,478)
$g.DrawString('Seen',$small,$muted,1278,422)
$g.DrawRectangle($pen,430,770,890,52);$g.DrawString('Message...',$regular,$muted,470,786);$g.DrawString('Send',$regular,$white,1250,786)
$im.Save((Join-Path $PWD 'dist\dm-example.png'),[Drawing.Imaging.ImageFormat]::Png)
$g.Dispose();$im.Dispose();$regular.Dispose();$small.Dispose();$bold.Dispose();$pen.Dispose();foreach($r in $resources){$r.Dispose()}

import { decode } from './verify-ocr-export.mjs';
import assert from 'node:assert/strict';
const before=await decode('dist/dm-example.png'),after=await decode(process.argv[2]||'.runtime/qa/dm-export.png');
assert.equal(after.width,before.width);assert.equal(after.height,before.height);
const regions=[
  ['header username',480,80,155,28,'#0c0c0c'],
  ['sidebar username 1',157,207,150,25,'#0c0c0c'],['sidebar username 2',157,295,150,25,'#0c0c0c'],['sidebar username 3',157,383,150,25,'#0c0c0c'],
  ['sidebar message 1',157,237,200,21,'#0c0c0c'],['sidebar message 2',157,325,200,21,'#0c0c0c'],['sidebar message 3',157,413,200,21,'#0c0c0c'],
  ['incoming message 1',484,227,330,26,'#262626'],['outgoing message 1',938,327,330,26,'#6651dc'],['outgoing message 2',938,358,330,26,'#6651dc'],
  ['incoming message 2',484,447,330,26,'#262626'],['incoming message 3',484,478,330,26,'#262626'],
  ['header avatar',421,78,40,40,'#0c0c0c'],['sidebar avatar 1',95,204,44,44,'#0c0c0c'],['sidebar avatar 2',95,292,44,44,'#0c0c0c'],['sidebar avatar 3',95,380,44,44,'#0c0c0c'],
  ['message avatar 1',424,234,28,28,'#0c0c0c'],['message avatar 2',424,468,28,28,'#0c0c0c']
];
const pixel=(image,x,y)=>[...image.pixels.subarray((y*image.width+x)*image.channels,(y*image.width+x)*image.channels+3)];
const counts=[];
for(const [name,x,y,w,h,color] of regions){
  const rgb=color.match(/[a-f\d]{2}/gi).map(n=>parseInt(n,16));let covered=0;
  for(let yy=y;yy<y+h;yy++)for(let xx=x;xx<x+w;xx++){
    if(pixel(before,xx,yy).every((v,i)=>v===rgb[i]))continue;
    assert.deepEqual(pixel(after,xx,yy),rgb,`${name} glyph/photo remains at ${xx},${yy}`);
    if(after.channels===4)assert.equal(after.pixels[(yy*after.width+xx)*4+3],255);
    covered++;
  }
  assert.ok(covered>30,name);counts.push({name,coveredPixels:covered,color});
}
let outsidePreserved=0;
for(let y=0;y<before.height;y++)for(let x=0;x<before.width;x++){
  if(regions.some(([,rx,ry,rw,rh])=>x>=rx-12&&x<rx+rw+12&&y>=ry-12&&y<ry+rh+12))continue;
  assert.deepEqual(pixel(after,x,y),pixel(before,x,y),`Unrelated UI changed at ${x},${y}`);outsidePreserved++;
}
console.log(JSON.stringify({success:true,width:after.width,height:after.height,regions:counts,outsidePixelsPreserved:outsidePreserved,metadataChunks:[...new Set(after.chunks)]},null,2));

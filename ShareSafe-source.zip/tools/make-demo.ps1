$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$projectPath = Split-Path $PSScriptRoot -Parent
$framePath = Join-Path $projectPath '.runtime\demo-frames'
$mediaPath = Join-Path $projectPath 'docs\media'
New-Item -ItemType Directory -Path $framePath -Force | Out-Null
$scenes = @(
  @{Title="ShareSafe`nScreenshot privacy";Bullets=@('Cover private details before sharing.','Add numbered pins for context.','Edit images in your browser.');Image='demo-03-pin.jpg';Seconds=7},
  @{Title="Open a`nscreenshot";Bullets=@('Open, paste, or drop an image.','PNG, JPG and WebP are supported.','This example uses fictional details.');Image='demo-01-original.jpg';Seconds=8},
  @{Title="Draw solid`ncovers";Bullets=@('Drag over names, messages or codes.','Move, resize and recolor each cover.','Use undo and redo to make changes.');Image='demo-02-covers.jpg';Seconds=8},
  @{Title="Add numbered`npins";Bullets=@('Click to point out a detail.','Pins are included in the exported PNG.','The image stays in browser memory.');Image='demo-03-pin.jpg';Seconds=7},
  @{Title="Review before`nexporting";Bullets=@('Check the whole image for private details.','Confirm the image size and edit count.','Private details are not detected automatically.');Image='demo-04-review.jpg';Seconds=8},
  @{Title="Download the`nflattened PNG";Bullets=@('Covers replace pixels in the exported file.','The export has no layers or undo history.','Built with HTML, CSS, JavaScript and Canvas.','Development assisted by OpenAI Codex.');Image='demo-05-export.png';Seconds=10}
)
$ink=[System.Drawing.SolidBrush]::new([System.Drawing.ColorTranslator]::FromHtml('#282c2a'))
$muted=[System.Drawing.SolidBrush]::new([System.Drawing.ColorTranslator]::FromHtml('#6e7864'))
$coral=[System.Drawing.SolidBrush]::new([System.Drawing.ColorTranslator]::FromHtml('#e66c4f'))
$white=[System.Drawing.SolidBrush]::new([System.Drawing.Color]::White)
$brandFont=[System.Drawing.Font]::new('Segoe UI',33,[System.Drawing.FontStyle]::Bold,[System.Drawing.GraphicsUnit]::Pixel)
$titleFont=[System.Drawing.Font]::new('Segoe UI',61,[System.Drawing.FontStyle]::Bold,[System.Drawing.GraphicsUnit]::Pixel)
$bodyFont=[System.Drawing.Font]::new('Segoe UI',28,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Pixel)
$smallFont=[System.Drawing.Font]::new('Segoe UI',20,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Pixel)
$border=[System.Drawing.Pen]::new([System.Drawing.ColorTranslator]::FromHtml('#dfe0d7'))
$concat=[System.Collections.Generic.List[string]]::new()
try {
  for($index=0;$index -lt $scenes.Count;$index++){
    $scene=$scenes[$index];$bitmap=[System.Drawing.Bitmap]::new(1920,1080)
    $g=[System.Drawing.Graphics]::FromImage($bitmap)
    $g.Clear([System.Drawing.ColorTranslator]::FromHtml('#f6f5f1'))
    $g.SmoothingMode=[System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.TextRenderingHint=[System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit
    $g.InterpolationMode=[System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    try {
      $g.FillRectangle($coral,80,58,18,18);$g.FillRectangle($coral,102,58,18,18)
      $g.FillRectangle($coral,80,80,18,18);$g.FillRectangle($ink,102,80,18,18)
      $g.DrawString('sharesafe.',$brandFont,$ink,137,53)
      $g.DrawString(('ICEHACKS 2026   /   {0:00} OF 06' -f ($index+1)),$smallFont,$muted,1500,65)
      $g.DrawString($scene.Title,$titleFont,$ink,[System.Drawing.RectangleF]::new(80,230,650,180))
      $bulletY=475
      foreach($bullet in $scene.Bullets){
        $g.FillEllipse($coral,84,$bulletY+14,7,7)
        $g.DrawString($bullet,$bodyFont,$muted,[System.Drawing.RectangleF]::new(109,$bulletY,600,80))
        $bulletY+=90
      }
      $image=[System.Drawing.Image]::FromFile((Join-Path $mediaPath $scene.Image))
      try {
        $scale=[Math]::Min(1040.0/$image.Width,770.0/$image.Height)
        $w=[int]($image.Width*$scale);$h=[int]($image.Height*$scale)
        $x=790+[int]((1040-$w)/2);$y=190+[int]((770-$h)/2)
        $g.FillRectangle($white,$x-1,$y-1,$w+2,$h+2)
        $g.DrawImage($image,[System.Drawing.Rectangle]::new($x,$y,$w,$h));$g.DrawRectangle($border,$x-1,$y-1,$w+2,$h+2)
      } finally { $image.Dispose() }
      $g.DrawString('Captioned walkthrough using actual editor captures. Example data is fictional.',$smallFont,$muted,80,1010)
      $frameName='scene-{0:00}.png' -f $index
      $bitmap.Save((Join-Path $framePath $frameName),[System.Drawing.Imaging.ImageFormat]::Png)
      $concat.Add("file '$frameName'");$concat.Add("duration $($scene.Seconds)")
    } finally { $g.Dispose();$bitmap.Dispose() }
  }
  $concat.Add("file 'scene-05.png'")
  $concat | Set-Content -LiteralPath (Join-Path $framePath 'scenes.txt') -Encoding utf8
} finally { foreach($r in @($ink,$muted,$coral,$white,$brandFont,$titleFont,$bodyFont,$smallFont,$border)){$r.Dispose()} }
$duration=($scenes | Measure-Object -Property Seconds -Sum).Sum
& ffmpeg -hide_banner -loglevel warning -y -f concat -safe 0 -i (Join-Path $framePath 'scenes.txt') -t $duration -vf 'fps=30,format=yuv420p' -c:v libx264 -preset medium -crf 19 -movflags +faststart -an (Join-Path $mediaPath 'ShareSafe-demo.mp4')
if($LASTEXITCODE -ne 0){throw 'Video rendering failed.'}
& ffprobe -v error -show_entries format=duration,size -show_entries stream=codec_name,width,height -of json (Join-Path $mediaPath 'ShareSafe-demo.mp4')

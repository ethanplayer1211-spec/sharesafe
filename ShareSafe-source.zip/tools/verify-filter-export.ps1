param([string]$ExportPath='.runtime\qa\filter-export.png')
$ErrorActionPreference='Stop'
Set-Location -LiteralPath (Split-Path $PSScriptRoot -Parent)
Add-Type -AssemblyName System.Drawing
$image=[Drawing.Bitmap]::new((Resolve-Path -LiteralPath $ExportPath).Path)
$original=[Drawing.Bitmap]::new((Join-Path $PWD 'dist\profile-example.png'))
$results=@()
try {
  if($image.Width -ne 1360 -or $image.Height -ne 860){throw 'Export dimensions changed.'}
  $regions=@(
    @{Name='profile photo';X=40;Y=100;W=80;H=80;All=$true},
    @{Name='picture';X=970;Y=100;W=320;H=220;All=$true},
    @{Name='username';X=175;Y=284;W=290;H=32;All=$false},
    @{Name='birthday';X=150;Y=348;W=290;H=32;All=$false},
    @{Name='address';X=160;Y=412;W=430;H=32;All=$false},
    @{Name='student ID';X=175;Y=476;W=200;H=32;All=$false}
  )
  foreach($region in $regions){
    $checked=0
    for($y=$region.Y;$y -lt $region.Y+$region.H;$y++){for($x=$region.X;$x -lt $region.X+$region.W;$x++){
      $sourcePixel=$original.GetPixel($x,$y)
      if(-not $region.All -and ($sourcePixel.R -gt 100 -or $sourcePixel.G -gt 100 -or $sourcePixel.B -gt 100)){continue}
      $pixel=$image.GetPixel($x,$y)
      if($pixel.R -ne 32 -or $pixel.G -ne 37 -or $pixel.B -ne 43 -or $pixel.A -ne 255){throw "Uncovered pixel in $($region.Name) at $x,$y"}
      $checked++
    }}
    if($checked -lt 100){throw "Too few fixture pixels in $($region.Name)"}
    $results+=@{Region=$region.Name;VerifiedOpaquePixels=$checked}
  }
  @{Success=$true;Width=$image.Width;Height=$image.Height;Regions=$results} | ConvertTo-Json -Depth 5
} finally {$original.Dispose();$image.Dispose()}

// Verify the actual browser-generated example PNG, independently of canvas rendering.
import { readFile } from 'node:fs/promises';
import { inflateSync } from 'node:zlib';
import assert from 'node:assert/strict';
const data = await readFile(process.argv[2]);
assert.equal(data.subarray(0,8).toString('hex'),'89504e470d0a1a0a');
let offset=8, width, height, channels, compressed=[], chunks=[];
while(offset<data.length){
  const length=data.readUInt32BE(offset), type=data.toString('ascii',offset+4,offset+8);
  const bytes=data.subarray(offset+8,offset+8+length); chunks.push(type);
  if(type==='IHDR'){
    width=bytes.readUInt32BE(0); height=bytes.readUInt32BE(4);
    assert.equal(bytes[8],8); assert.ok([2,6].includes(bytes[9])); assert.equal(bytes[12],0);
    channels=bytes[9]===6?4:3;
  }
  if(type==='IDAT')compressed.push(bytes);
  offset+=length+12;
}
assert.equal(width,1280); assert.equal(height,800);
assert.ok(!chunks.some(t=>['tEXt','zTXt','iTXt','eXIf'].includes(t)), 'No original metadata should be attached');
const raw=inflateSync(Buffer.concat(compressed)), stride=width*channels, pixels=Buffer.alloc(height*stride);
function paeth(a,b,c){const p=a+b-c,pa=Math.abs(p-a),pb=Math.abs(p-b),pc=Math.abs(p-c);return pa<=pb&&pa<=pc?a:pb<=pc?b:c;}
for(let y=0;y<height;y++){
  const filter=raw[y*(stride+1)];
  assert.ok(filter<=4);
  for(let x=0;x<stride;x++){
    const i=y*stride+x,a=x>=channels?pixels[i-channels]:0,b=y?pixels[i-stride]:0,c=y&&x>=channels?pixels[i-stride-channels]:0;
    const predict=[0,a,b,Math.floor((a+b)/2),paeth(a,b,c)][filter];
    pixels[i]=(raw[y*(stride+1)+1+x]+predict)&255;
  }
}
let coveredPixels=0;
for(const [x,y,w,h] of [[304,211,265,18],[482,596,244,21]]){
  for(let row=y;row<y+h;row++)for(let col=x;col<x+w;col++){
    const i=(row*width+col)*channels;
    assert.deepEqual([...pixels.subarray(i,i+3)],[32,37,43],`Opaque cover at ${col},${row}`);
    if(channels===4)assert.equal(pixels[i+3],255);
    coveredPixels++;
  }
}
console.log(JSON.stringify({success:true,width,height,coveredPixels,chunks,originalMetadataAttached:false},null,2));

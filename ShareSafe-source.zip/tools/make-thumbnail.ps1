$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$mediaPath = Join-Path (Split-Path $PSScriptRoot -Parent) 'docs\media'
New-Item -ItemType Directory -Path $mediaPath -Force | Out-Null
$bitmap = [System.Drawing.Bitmap]::new(1200,800)
$graphics = [System.Drawing.Graphics]::FromImage($bitmap)
$graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
$graphics.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit
$graphics.Clear([System.Drawing.ColorTranslator]::FromHtml('#f6f5f1'))
function Brush([string]$color) { [System.Drawing.SolidBrush]::new([System.Drawing.ColorTranslator]::FromHtml($color)) }
$ink=Brush '#282c2a';$coral=Brush '#e66c4f';$muted=Brush '#81847d';$green=Brush '#355b44';$white=Brush '#fffefa'
$logo=[System.Drawing.Font]::new('Segoe UI',31,[System.Drawing.FontStyle]::Bold,[System.Drawing.GraphicsUnit]::Pixel)
$hero=[System.Drawing.Font]::new('Georgia',85,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Pixel)
$body=[System.Drawing.Font]::new('Segoe UI',24,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Pixel)
$small=[System.Drawing.Font]::new('Segoe UI',15,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Pixel)
$strong=[System.Drawing.Font]::new('Segoe UI',23,[System.Drawing.FontStyle]::Bold,[System.Drawing.GraphicsUnit]::Pixel)
try {
  $graphics.FillRectangle($coral,72,68,17,17);$graphics.FillRectangle($coral,93,68,17,17)
  $graphics.FillRectangle($coral,72,89,17,17);$graphics.FillRectangle($ink,93,89,17,17)
  $graphics.DrawString('sharesafe.',$logo,$ink,125,62)
  $graphics.DrawString('BROWSER-LOCAL SCREENSHOT STUDIO',$small,$green,750,79)
  $graphics.DrawString('Redact screenshots.',$hero,$ink,66,157)
  $graphics.DrawString('Hide private details. Add numbered pins. Export a PNG.',$body,$muted,74,273)
  $features=@(@('01','Solid redactions','Cover names, messages and codes.'),@('02','Numbered pins','Add context to your image.'),@('03','PNG export','Keep the original resolution.'))
  $y=370
  foreach($feature in $features){
    $graphics.DrawString($feature[0],$small,$coral,76,$y+7)
    $graphics.DrawString($feature[1],$strong,$ink,113,$y)
    $graphics.DrawString($feature[2],$small,$muted,113,$y+36)
    $y+=100
  }
  $previewPath=Join-Path (Split-Path $PSScriptRoot -Parent) 'docs\preview.jpg'
  $preview=[System.Drawing.Image]::FromFile($previewPath)
  try{
    $graphics.FillRectangle($white,453,347,680,385)
    $graphics.DrawImage($preview,[System.Drawing.Rectangle]::new(454,348,678,383))
    $border=[System.Drawing.Pen]::new([System.Drawing.ColorTranslator]::FromHtml('#dfe0d7'))
    try{$graphics.DrawRectangle($border,453,347,680,385)}finally{$border.Dispose()}
  }finally{$preview.Dispose()}
  $graphics.DrawString('IceHacks 2026  /  No image uploads  /  No runtime AI API',$small,$muted,75,757)
  $bitmap.Save((Join-Path $mediaPath 'sharesafe-thumbnail.png'),[System.Drawing.Imaging.ImageFormat]::Png)
} finally {
  $graphics.Dispose();$bitmap.Dispose()
  foreach($resource in @($ink,$coral,$muted,$green,$white,$logo,$hero,$body,$small,$strong)){$resource.Dispose()}
}

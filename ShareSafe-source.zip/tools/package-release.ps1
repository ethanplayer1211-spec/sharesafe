$ErrorActionPreference='Stop'
Set-Location -LiteralPath (Split-Path $PSScriptRoot -Parent)
& node tools/build-portable.mjs
if($LASTEXITCODE -ne 0){throw 'Build failed.'}
$sourceFiles=@('dist','src','README.md','server.mjs','package.json','Start ShareSafe.cmd','ShareSafe.html','LICENSE','tests','tools','docs','preview.jpg','.gitignore')
Compress-Archive -LiteralPath $sourceFiles -DestinationPath 'release\ShareSafe-source.zip' -Force
Copy-Item -LiteralPath 'README.md','LICENSE','preview.jpg','docs\media\ShareSafe-demo.mp4','docs\media\sharesafe-thumbnail.png' -Destination 'release'
Copy-Item -LiteralPath 'release\ShareSafe-source.zip' -Destination 'ShareSafe-prototype.zip'
Get-Item -LiteralPath 'ShareSafe.html','dist\index.html','release\ShareSafe-source.zip' | Select-Object Name,Length

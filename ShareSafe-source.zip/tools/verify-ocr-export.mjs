// Independently decode actual browser PNGs, including PNG row filters. Comparing
// the original export to the applied OCR covers catches accidental preview marks.
import { readFile } from 'node:fs/promises';
import { inflateSync } from 'node:zlib';
import assert from 'node:assert/strict';
async function decode(path) {
  const file=await readFile(path); assert.equal(file.subarray(0,8).toString('hex'),'89504e470d0a1a0a');
  let offset=8,width,height,channels; const chunks=[],compressed=[];
  while(offset<file.length){
    const len=file.readUInt32BE(offset),type=file.toString('ascii',offset+4,offset+8),b=file.subarray(offset+8,offset+8+len); chunks.push(type);
    if(type==='IHDR'){width=b.readUInt32BE(0);height=b.readUInt32BE(4);assert.equal(b[8],8);assert.ok([2,6].includes(b[9]));assert.equal(b[12],0);channels=b[9]===6?4:3;}
    if(type==='IDAT')compressed.push(b);offset+=len+12;
  }
  assert.ok(!chunks.some(t=>['tEXt','zTXt','iTXt','eXIf'].includes(t)));
  const raw=inflateSync(Buffer.concat(compressed)),stride=width*channels,pixels=Buffer.alloc(height*stride);
  const paeth=(a,b,c)=>{const p=a+b-c,pa=Math.abs(p-a),pb=Math.abs(p-b),pc=Math.abs(p-c);return pa<=pb&&pa<=pc?a:pb<=pc?b:c;};
  for(let y=0;y<height;y++)for(let x=0;x<stride;x++){
    const filter=raw[y*(stride+1)];assert.ok(filter<=4);
    const i=y*stride+x,a=x>=channels?pixels[i-channels]:0,b=y?pixels[i-stride]:0,c=y&&x>=channels?pixels[i-stride-channels]:0;
    pixels[i]=(raw[y*(stride+1)+1+x]+[0,a,b,Math.floor((a+b)/2),paeth(a,b,c)][filter])&255;
  }
  return {width,height,channels,pixels,chunks};
}
const before=await decode(process.argv[2]),after=await decode(process.argv[3]);
assert.equal(before.width,1280);assert.equal(before.height,800);
assert.equal(after.width,before.width);assert.equal(after.height,before.height);
const regions=[{name:'email',x:350,y:208,w:260,h:25},{name:'private code',x:477,y:592,w:260,h:28}];
const counts=regions.map(()=>0);let changed=0;
for(let y=0;y<after.height;y++)for(let x=0;x<after.width;x++){
  const a=(y*after.width+x)*after.channels,b=(y*before.width+x)*before.channels;
  if(after.pixels.subarray(a,a+3).equals(before.pixels.subarray(b,b+3)))continue;
  const region=regions.findIndex(r=>x>=r.x&&x<r.x+r.w&&y>=r.y&&y<r.y+r.h);
  assert.notEqual(region,-1,`Unexpected preview/annotation pixel at ${x},${y}`);
  assert.deepEqual([...after.pixels.subarray(a,a+3)],[32,37,43]);
  if(after.channels===4)assert.equal(after.pixels[a+3],255);
  counts[region]++;changed++;
}
assert.ok(counts.every(n=>n>1000),'Both details must receive substantial opaque covers');
console.log(JSON.stringify({success:true,width:after.width,height:after.height,changedPixels:changed,regions:regions.map((r,i)=>({name:r.name,coveredPixels:counts[i]})),chunks:after.chunks,previewMarksExported:false,originalMetadataAttached:false},null,2));

import { createWorker } from 'tesseract.js';
import { resolve } from 'node:path';
import { writeFile } from 'node:fs/promises';
import { deflateSync } from 'node:zlib';
import { decode } from './verify-ocr-export.mjs';
import { ocrSegments } from '../dist/privacy.js';
import { analyzeChat,chatAvatars,chatDividers } from '../dist/chat.js';
import { normalizeTextContrast } from '../dist/ocr.js';
import assert from 'node:assert/strict';
function pngRGBA(data,width,height){
  const crc=b=>{let c=0xffffffff;for(const n of b){c^=n;for(let j=0;j<8;j++)c=(c>>>1)^((c&1)?0xedb88320:0);}return (c^0xffffffff)>>>0;};
  const chunk=(type,data)=>{const t=Buffer.from(type),b=Buffer.alloc(data.length+12);b.writeUInt32BE(data.length,0);t.copy(b,4);data.copy(b,8);b.writeUInt32BE(crc(Buffer.concat([t,data])),data.length+8);return b;};
  const h=Buffer.alloc(13);h.writeUInt32BE(width,0);h.writeUInt32BE(height,4);h[8]=8;h[9]=6;
  const scan=Buffer.alloc(height*(width*4+1));for(let y=0;y<height;y++)Buffer.from(data.buffer,data.byteOffset+y*width*4,width*4).copy(scan,y*(width*4+1)+1);
  return Buffer.concat([Buffer.from('89504e470d0a1a0a','hex'),chunk('IHDR',h),chunk('IDAT',deflateSync(scan)),chunk('IEND',Buffer.alloc(0))]);
}
const path=resolve(process.argv[2]||'dist/dm-example.png');
const scale=Number(process.argv[3]||1);
const worker=await createWorker('eng',1,{langPath:resolve('node_modules/@tesseract.js-data/eng/4.0.0_best_int'),cacheMethod:'none'});
try{
  await worker.setParameters({tessedit_pageseg_mode:'11'});
  const image=await decode(path),rgba=new Uint8ClampedArray(image.width*image.height*4);
  for(let i=0;i<image.width*image.height;i++){rgba.set(image.pixels.subarray(i*image.channels,i*image.channels+3),i*4);rgba[i*4+3]=255;}
  const enlarged=new Uint8ClampedArray(image.width*image.height*scale*scale*4),ew=image.width*scale,eh=image.height*scale;
  for(let y=0;y<eh;y++)for(let x=0;x<ew;x++){
    const xx=Math.max(0,(x+.5)/scale-.5),yy=Math.max(0,(y+.5)/scale-.5),x0=Math.floor(xx),y0=Math.floor(yy),x1=Math.min(image.width-1,x0+1),y1=Math.min(image.height-1,y0+1),fx=xx-x0,fy=yy-y0;
    for(let c=0;c<4;c++)enlarged[(y*ew+x)*4+c]=rgba[(y0*image.width+x0)*4+c]*(1-fx)*(1-fy)+rgba[(y0*image.width+x1)*4+c]*fx*(1-fy)+rgba[(y1*image.width+x0)*4+c]*(1-fx)*fy+rgba[(y1*image.width+x1)*4+c]*fx*fy;
  }
  const normalized=normalizeTextContrast({data:enlarged,width:ew,height:eh});
  await writeFile('.runtime/qa/dm-normalized.png',pngRGBA(normalized.data,ew,eh));
  const {data}=await worker.recognize(pngRGBA(normalized.data,ew,eh),{}, {blocks:true});
  const pixels={width:image.width,height:image.height,data:rgba},rows=ocrSegments(data,scale);
  const avatars=chatAvatars(pixels,rows),dividers=chatDividers(pixels),chat=analyzeChat(data,image.width,image.height,scale,{avatars,dividers});
  await writeFile('.runtime/qa/dm-scan.json',JSON.stringify({data,scale,avatars,dividers,chat}));
  console.log(JSON.stringify({detected:chat.detected,area:chat.area,dividers,avatars:avatars.map(a=>({x:a.x,y:a.y,w:a.w,h:a.h})),categories:chat.findings.reduce((n,f)=>(n[f.kind]=(n[f.kind]||0)+1,n),{})},null,2));
  assert.equal(chat.detected,true);assert.equal(avatars.length,6);assert.equal(chat.findings.filter(f=>f.kind==='username').length,5);assert.equal(chat.findings.filter(f=>f.kind==='message').length,8);
}finally{await worker.terminate();}

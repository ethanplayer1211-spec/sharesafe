import asyncio,json,sys,subprocess,math
from pathlib import Path
sys.path.insert(0,str(Path('.runtime/tts').resolve()))
import edge_tts
root=Path('.runtime/demo-frames');root.mkdir(parents=True,exist_ok=True)
scripts=[
'ShareSafe helps you share a screenshot without sharing private details. Open an image to start scanning on your device.',
'Choose what to hide: names, usernames, messages, photos, birthdays, contact details, or secrets. You can add your own words.',
'Black covers replace the private pixels. One switch changes every cover, and you can undo the change.',
'Prefer a softer look? Choose blur. For stronger concealment, use black and inspect the edges.',
'I tested five randomly selected, fictional screenshots: Arc, Slack, GitHub, Terminal, and Cursor. Both export styles were checked.',
'Review still matters. Two examples needed an extra manual cover, and one incorrect name suggestion was rejected.',
'Preview your changes before applying them. Then check the full image and download a PNG at its original resolution.',
'Your screenshot stays in the browser. No account, API key, or image upload is needed.'
]
async def speak(i,text):
 cached=root/f'voice-{i:02}.json'
 if cached.exists() and (root/f'voice-{i:02}.mp3').stat().st_size>1000:return json.loads(cached.read_text(encoding='utf-8'))
 words=[]
 communication=edge_tts.Communicate(text,voice='en-US-AndrewNeural',rate='+3%',boundary='WordBoundary')
 with (root/f'voice-{i:02}.mp3').open('wb') as f:
  async for part in communication.stream():
   if part['type']=='audio':f.write(part['data'])
   elif part['type']=='WordBoundary':words.append({'start':part['offset']/1e7,'end':(part['offset']+part['duration'])/1e7,'word':part['text']})
 duration=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(root/f'voice-{i:02}.mp3')],text=True).strip())
 print(json.dumps({'scene':i+1,'voice':'en-US-AndrewNeural','speechSeconds':duration,'words':len(words)}),flush=True)
 result={'text':text,'duration':math.ceil((duration+.8)*30)/30,'speech':duration,'words':words}
 cached.write_text(json.dumps(result,indent=2),encoding='utf-8')
 return result
async def main():
 result=[]
 for i,text in enumerate(scripts):
  for attempt in range(3):
   try:
    result.append(await asyncio.wait_for(speak(i,text),timeout=25));break
   except Exception as error:
    print(json.dumps({'scene':i+1,'attempt':attempt+1,'retry':type(error).__name__}),flush=True)
    if attempt==2:raise
    await asyncio.sleep(1.2)
 (root/'narration.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
asyncio.run(main())

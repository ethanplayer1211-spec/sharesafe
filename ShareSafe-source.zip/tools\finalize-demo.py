import json,re,subprocess,math,shutil
from pathlib import Path
root=Path('.runtime/demo-frames').resolve();scenes=json.loads((root/'narration.json').read_text(encoding='utf-8'))
def stamp(t):
 n=round(t*1000);h,n=divmod(n,3600000);m,n=divmod(n,60000);s,ms=divmod(n,1000);return f'{h:02}:{m:02}:{s:02},{ms:03}'
subtitles=[];offset=0
for i,scene in enumerate(scenes):
 words=scene['words'];original=scene['text'].split()
 clean=lambda t:re.sub(r'[^\w]','',t).lower()
 assert clean(''.join(w['word'] for w in words))==clean(scene['text']),f'Speech timing text mismatch in scene {i+1}'
 displays=original if len(original)==len(words) else [w['word'] for w in words]
 group=[]
 for j,w in enumerate(words):
  group.append((w,displays[j]))
  if len(group)>=7 or j==len(words)-1 or displays[j].endswith(('.', '?', '!')):
   start=offset+.35+group[0][0]['start'];end=min(offset+scene['duration']-.15,offset+.35+group[-1][0]['end']+.12)
   text=' '.join(a[1] for a in group)
   if len(text)>54:
    mid=min(range(1,len(group)),key=lambda k:abs(len(' '.join(a[1] for a in group[:k]))-len(text)/2));text=' '.join(a[1] for a in group[:mid])+'\n'+' '.join(a[1] for a in group[mid:])
   subtitles.append({'start':start,'end':end,'text':text,'scene':i+1});group=[]
 offset+=scene['duration']
for a,b in zip(subtitles,subtitles[1:]):
 a['end']=min(a['end'],b['start']-.02)
 assert a['end']>a['start'] and a['end']<=b['start']
srt='\n\n'.join(f'{i+1}\n{stamp(c["start"])} --> {stamp(c["end"])}\n{c["text"]}' for i,c in enumerate(subtitles))+'\n'
(root/'captions.srt').write_text(srt,encoding='utf-8');
def ass_time(t):
 n=round(t*100);h,n=divmod(n,360000);m,n=divmod(n,6000);sec,cs=divmod(n,100);return f'{h}:{m:02}:{sec:02}.{cs:02}'
ass='''[Script Info]
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
WrapStyle: 2
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Segoe UI,38,&H00FFFFFF,&H00FFFFFF,&H50000000,&H50000000,0,0,0,0,100,100,0,0,3,3,0,2,80,80,32,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
for cue in subtitles:
 text=cue['text'].replace(chr(10),'\\N')
 ass+=f"Dialogue: 0,{ass_time(cue['start'])},{ass_time(cue['end'])},Default,,0,0,0,,{text}\n"
(root/'captions.ass').write_text(ass,encoding='utf-8')
(root/'caption-check.json').write_text(json.dumps({'duration':offset,'voice':'en-US-AndrewNeural','gender':'Male','captions':subtitles},indent=2),encoding='utf-8')
args=['ffmpeg','-hide_banner','-loglevel','error','-y']
for i in range(8):args+=['-i',str(root/f'voice-{i:02}.mp3')]
filters=[]
for i,s in enumerate(scenes):filters.append(f'[{i}:a]adelay=350:all=1,apad,atrim=duration={s["duration"]:.6f},asetpts=PTS-STARTPTS[a{i}]')
filters.append(''.join(f'[a{i}]' for i in range(8))+'concat=n=8:v=0:a=1,loudnorm=I=-16:TP=-1.5:LRA=7[voice]')
args+=['-filter_complex',';'.join(filters),'-map','[voice]','-ar','48000',str(root/'narration.wav')];subprocess.run(args,check=True)
subprocess.run(['powershell','-NoProfile','-ExecutionPolicy','Bypass','-File','tools/make-demo.ps1'],check=True)
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i','clean-base.mp4','-i','narration.wav','-i','captions.srt','-vf',"ass=captions.ass",'-map','0:v:0','-map','1:a:0','-map','2:s:0','-c:v','libx264','-preset','medium','-crf','19','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-c:s','mov_text','-metadata:s:s:0','language=eng','-metadata:s:a:0','language=eng','-disposition:s:0','0','-t',f'{offset:.6f}','-movflags','+faststart','narrated-final.mp4'],cwd=root,check=True)
media=Path('docs/media');shutil.copyfile(root/'narrated-final.mp4',media/'ShareSafe-demo.mp4');shutil.copyfile(root/'captions.srt',media/'ShareSafe-demo.srt');shutil.copyfile(root/'caption-check.json',media/'caption-check.json')
print(json.dumps({'duration':offset,'captionCues':len(subtitles),'voice':'en-US-AndrewNeural','file':str(media/'ShareSafe-demo.mp4')}))

import test from 'node:test';
import assert from 'node:assert/strict';
import nlp from 'compromise';
import { privateMatches, findingsFromOCR, filterFindings, customTerms } from '../dist/privacy.js';
import { detectPictureRegions } from '../dist/pictures.js';

test('names, handles and personal fields produce separate filter categories',()=>{
  for(const [text,kind] of [['Full name: Alex Morgan','name'],['Name: 김민수','name'],['@creator_alex','username'],['Username: creator_alex','username'],['DOB: 2008-12-11','birthday'],['Birthday: December 11, 2008','birthday'],['Born on 11 December 2008','birthday'],['Address: 120 Oak Street, Example City','personal'],['Passport number: AB1234567','personal'],['Age: 17','personal'],['Gender: Female','personal'],['120 Oak Street','personal']]) {
    const m=privateMatches(text);assert.equal(m.length,1,text);assert.equal(m[0].kind,kind,text);
  }
  assert.deepEqual(privateMatches('Next meeting: 2008-12-11'),[]);
  assert.deepEqual(privateMatches('DOB: 2008-02-31'),[]);
  assert.equal(privateMatches('Birthday: 2008-02-29')[0].kind,'birthday');
  assert.deepEqual(privateMatches('alex@example.com').map(f=>f.kind),['email']);
  const spaced=privateMatches('Email: alex . morgan @ example . com');
  assert.equal(spaced.length,1);assert.equal(spaced[0].start,7);assert.equal(spaced[0].end,36);
});
test('the actual local recognizer finds unlabelled names without tagging the workspace title',()=>{
  const detect=text=>privateMatches(text,{people:nlp(text).people().out('array')});
  assert.deepEqual(detect('Jamie at Northstar').map(m=>m.kind),['name']);
  assert.equal(detect('to Alex Morgan · alex.morgan@example.com').filter(m=>m.kind==='name').length,1);
  assert.deepEqual(detect('Your Fieldnotes workspace is ready.'),[]);
});
test('filter changes preserve explicit words and do not modify the source findings',()=>{
  const findings=[{kind:'name'},{kind:'email'},{kind:'phone'},{kind:'avatar'},{kind:'custom'}];
  assert.deepEqual(filterFindings(findings,new Set(['contact'])).map(f=>f.kind),['email','phone','custom']);
  assert.deepEqual(filterFindings(findings,new Set()).map(f=>f.kind),['custom']);
  assert.equal(findings.length,5);
  assert.deepEqual(customTerms('Alex Morgan, secret phrase\nAlex Morgan, x'),['Alex Morgan','secret phrase']);
  assert.equal(privateMatches('A project called C++ (private)',{custom:['C++ (private)']})[0].kind,'custom');
  assert.deepEqual(privateMatches('Alexis',{custom:['Alex']}),[]);
  assert.deepEqual(privateMatches('alex@example.com',{custom:['alex@example.com']}).map(f=>f.kind),['custom']);
  const wider=privateMatches('Alex Morgan',{custom:['Alex'],people:['Alex Morgan']});
  assert.deepEqual(wider,[{kind:'custom',start:0,end:11}]);
});
test('name recognition and custom phrases map to the full OCR token region',()=>{
  const data={blocks:[{paragraphs:[{lines:[{words:[{text:'Alex',bbox:{x0:20,y0:20,x1:60,y1:40}},{text:'Morgan',bbox:{x0:66,y0:20,x1:120,y1:40}}]}]}]}]};
  const f=findingsFromOCR(data,200,80,1,{findPeople:t=>nlp(t).people().out('array')});
  assert.equal(f.length,1);assert.equal(f[0].kind,'name');assert.deepEqual([f[0].x,f[0].y,f[0].w,f[0].h],[18,18,104,24]);
});
test('an avatar misread as punctuation does not expand a name box across the photo',()=>{
  const data={blocks:[{paragraphs:[{lines:[{words:[{text:'-',bbox:{x0:10,y0:10,x1:70,y1:70}},{text:'Alex',bbox:{x0:90,y0:25,x1:130,y1:45}},{text:'Morgan',bbox:{x0:140,y0:25,x1:200,y1:45}}]}]}]}]};
  const f=findingsFromOCR(data,300,100,1,{findPeople:t=>nlp(t).people().out('array')});
  assert.equal(f[0].kind,'name');assert.equal(f[0].x,88);
});

function raster(width=400,height=300) {
  const data=new Uint8ClampedArray(width*height*4).fill(255);
  return {width,height,data};
}
function paint(image,x,y,w,h,color){
  for(let yy=y;yy<y+h;yy++)for(let xx=x;xx<x+w;xx++){
    const rgb=typeof color==='function'?color(xx,yy):color,i=(yy*image.width+xx)*4;
    image.data.set([...rgb,255],i);
  }
}
test('visual regions separate a small profile image from a larger textured picture',()=>{
  const im=raster();
  paint(im,20,30,40,40,[210,120,85]);
  paint(im,150,80,160,100,(x,y)=>[70+(x*y%110),80+(x*7+y*11)%100,130+(x+y)%90]);
  paint(im,20,240,260,24,[70,130,190]); // A wide flat button is not a photo.
  const f=detectPictureRegions(im,400,300,{peopleBoxes:[{x:70,y:30,w:90,h:20}]});
  assert.deepEqual(f.map(r=>r.kind).sort(),['avatar','picture']);
  assert.ok(f.find(r=>r.kind==='avatar').x<20);
  assert.ok(f.find(r=>r.kind==='picture').w>=160);
});
test('ordinary OCR text and blank panels are not suggested as pictures',()=>{
  const im=raster();paint(im,20,20,50,24,(x,y)=>x%4<2?[20,20,20]:[255,255,255]);
  paint(im,140,60,200,150,[242,244,235]);
  paint(im,100,220,24,24,[70,130,90]); // A flat app icon without name context.
  const f=detectPictureRegions(im,400,300,{textBoxes:[{text:'Example',x:20,y:20,w:50,h:24}]});
  assert.deepEqual(f,[]);
});

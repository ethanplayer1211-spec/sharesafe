import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { Script } from 'node:vm';

test('the default dist entry is the complete offline application, with no module fetches', async () => {
  const html = await readFile('dist/index.html','utf8');
  assert.equal(html, await readFile('release/ShareSafe.html','utf8'));
  assert.equal(html, await readFile('ShareSafe.html','utf8'));
  assert.doesNotMatch(html, /<script\b[^>]*\b(?:src|type)\s*=/i);
  assert.doesNotMatch(html, /<link\b[^>]*rel="stylesheet"/i);
  assert.match(html, /data:image\/svg\+xml;base64,/);
  assert.doesNotMatch(html, /loadImage\('\.\/example\.svg'/);
  const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)];
  assert.equal(scripts.length,1);
  const script = scripts[0][1];
  assert.doesNotMatch(script, /^\s*(?:import|export)\s/m);
  assert.ok(html.indexOf('<script>') > html.indexOf('id="file-input"'));
  assert.ok(html.indexOf('<script>') > html.indexOf('id="export-dialog"'));
  assert.doesNotThrow(() => new Script(script));
});

test('the delivered inline code and styles match CSP hashes after HTML newline normalization', async () => {
  const html = (await readFile('dist/index.html','utf8')).replace(/\r\n?/g,'\n');
  const policy = html.match(/http-equiv="Content-Security-Policy" content="([^"]+)"/)[1];
  for(const tag of ['script','style']){
    const content=html.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)</${tag}>`))[1];
    const hash=createHash('sha256').update(content).digest('base64');
    assert.ok(policy.includes(`'sha256-${hash}'`),`${tag} must be authorized by the delivered policy`);
  }
  assert.match(policy,/connect-src 'none'/);
  assert.doesNotMatch(policy,/unsafe-inline|unsafe-eval/);
});

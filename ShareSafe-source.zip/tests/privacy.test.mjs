import test from 'node:test';
import assert from 'node:assert/strict';
import { privateMatches, findingsFromOCR, validCard } from '../dist/privacy.js';

test('structured private details are detected without treating everyday dates as secrets', () => {
  const text = 'alex@example.com | +1 (415) 555-0123 | 192.168.1.24 | 4111 1111 1111 1111 | password: flower-garden | 2026-11-16';
  assert.deepEqual(privateMatches(text).map(m=>m.kind), ['email','phone','ip','card','secret']);
  assert.deepEqual(privateMatches('Today 9:41 AM · 1280 x 800 · 2026-11-16 · 999.999.1.2 · 1234 5678 9012 3456'), []);
  assert.equal(validCard('4111-1111-1111-1111'),true);
  assert.equal(validCard('4111-1111-1111-1112'),false);
  assert.equal(validCard('0000000000000000'),false);
});
test('credentials, private workspace codes and spaced OCR emails are suggestions', () => {
  for (const [text,kind] of [['API key: sk-proj-abcdefghijklmnop1234','secret'],['Your private workspace code: NORTHSTAR-0824-PRIVATE','secret'],['alex.morgan @ example . com','email'],['phone: 4155550123','phone'],['ghp_abcdefghijklmnop123456','secret']]) {
    const matches=privateMatches(text); assert.equal(matches.length,1,text); assert.equal(matches[0].kind,kind);
  }
});
test('word boxes map back to source pixels, cover whole tokens, and clamp to image edges', () => {
  const data={blocks:[{paragraphs:[{lines:[{words:[
    {text:'Email:',bbox:{x0:0,y0:0,x1:70,y1:25}},
    {text:'alex',bbox:{x0:80,y0:0,x1:120,y1:25}},
    {text:'@',bbox:{x0:123,y0:0,x1:140,y1:25}},
    {text:'example.com',bbox:{x0:143,y0:0,x1:260,y1:25}}
  ]}]}]}]};
  const f=findingsFromOCR(data,130,30,2); assert.equal(f.length,1);
  assert.deepEqual(f[0],{id:'scan-0',kind:'email',x:38,y:0,w:92,h:15});
  assert.deepEqual(findingsFromOCR({blocks:null},100,100),[]);
});
test('a credential value in a separate OCR block is joined to its visual label', () => {
  const words=[['Private workspace code:',10,180],['NORTHSTAR-0824-PRIVATE',200,410]];
  const data={blocks:words.map(([text,x0,x1])=>({paragraphs:[{lines:[{words:[{text,bbox:{x0,y0:30,x1,y1:50}}]}]}]}))};
  const f=findingsFromOCR(data,500,100); assert.equal(f.length,1); assert.equal(f[0].kind,'secret'); assert.equal(f[0].x,198); assert.equal(f[0].w,214);
});

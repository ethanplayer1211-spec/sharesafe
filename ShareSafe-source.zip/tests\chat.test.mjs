import test from 'node:test';
import assert from 'node:assert/strict';
import { analyzeChat,chatAvatars,chatDividers } from '../dist/chat.js';
import { findingsFromOCR,ocrSegments } from '../dist/privacy.js';
import { drawComposite } from '../dist/core.js';
import { detectPictureRegions } from '../dist/pictures.js';
import { normalizeTextContrast } from '../dist/ocr.js';
const row=(text,x,y,w=text.length*8,h=18)=>({words:[{text,bbox:{x0:x,y0:y,x1:x+w,y1:y+h}}]});
const ocr=rows=>({blocks:[{paragraphs:[{lines:rows}]}]});
test('DM layout detects plain usernames and personal messages without needing private keywords',()=>{
  const data=ocr([row('Messages',100,80),row('mira.photos',155,210),row('alexmorgan',155,300),row('mira.photos',480,80),row('Active now',480,108),row('Today 9:41 AM',810,168),row('Can you send the draft tonight?',484,227),row('Sure. Keep this between us.',938,330),row('Message...',470,786),row('Send',1250,786)]);
  const avatars=[{x:95,y:204,w:44,h:44},{x:95,y:290,w:44,h:44},{x:420,y:76,w:40,h:40}];
  const result=analyzeChat(data,1360,860,1,{dividers:[400],avatars});
  assert.equal(result.detected,true);
  assert.equal(result.findings.filter(f=>f.kind==='username').length,3);
  assert.equal(result.findings.filter(f=>f.kind==='message').length,2);
  assert.ok(result.findings.every(f=>f.h<=22));
  assert.equal(analyzeChat(data,1360,860,1,{mode:'general'}).findings.length,0);
  const custom=analyzeChat(data,1360,860,1,{area:{x:450,y:200,w:890,h:400},avatars,dividers:[400]});
  assert.equal(custom.findings.filter(f=>f.kind==='message').length,2);
});
test('manual conversation bounds constrain message detection and general pages stay unclassified',()=>{
  const data=ocr([row('Some unrelated heading',20,40),row('hello there',100,200),row('secret message',600,300)]);
  assert.equal(analyzeChat(data,1000,700).detected,false);
  const result=analyzeChat(data,1000,700,1,{mode:'chat',area:{x:500,y:200,w:450,h:300}});
  assert.equal(result.findings.length,1);assert.equal(result.findings[0].x,598);
});
test('OCR columns are separated instead of producing a cover across unrelated content',()=>{
  const data=ocr([{words:[{text:'Name:',bbox:{x0:10,y0:20,x1:60,y1:40}},{text:'Alex',bbox:{x0:75,y0:20,x1:115,y1:40}},{text:'Project notes',bbox:{x0:600,y0:20,x1:780,y1:40}}]}]);
  assert.equal(ocrSegments(data).length,2);
  const f=findingsFromOCR(data,1000,700);assert.equal(f.length,1);assert.ok(f[0].x+f[0].w<130);
});
test('a dark application background cannot become a full-image picture cover',()=>{
  const data=new Uint8ClampedArray(400*300*4);
  for(let i=0;i<data.length;i+=4){const n=(i/4)%7;data.set([25+n*4,28+n*4,40+n*4,255],i);}
  assert.deepEqual(detectPictureRegions({data,width:400,height:300}),[]);
});
test('circle detection finds grayscale avatars near text and identifies the chat divider',()=>{
  const width=600,height=400,data=new Uint8ClampedArray(width*height*4);
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    const circle=Math.hypot(x-170,y-140)<20;const v=circle?160:12;const i=(y*width+x)*4;
    data.set([x===200?55:v,x===200?55:v,x===200?55:v,255],i);
  }
  const rows=ocrSegments(ocr([row('mira.photos',214,130,90,18)]));
  const avatars=chatAvatars({data,width,height},rows);
  assert.ok(avatars.some(a=>Math.abs(a.x+a.w/2-170)<6&&Math.abs(a.y+a.h/2-140)<6));
  assert.ok(chatDividers({data,width,height}).some(x=>Math.abs(x-200)<8));
});
test('contrast normalization recovers light text on colored bubbles without changing source pixels',()=>{
  const width=256,height=128,source=new Uint8ClampedArray(width*height*4);
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    const bubble=x>=20&&x<236&&y>=15&&y<110,glyph=x>=60&&x<68&&y>=40&&y<60;
    source.set(glyph?[245,245,245,255]:bubble?[102,81,220,255]:[12,12,12,255],(y*width+x)*4);
  }
  const original=new Uint8ClampedArray(source),result=normalizeTextContrast({data:new Uint8ClampedArray(source),width,height});
  assert.equal(result.data[(45*width+62)*4],0);assert.equal(result.data[(45*width+90)*4],255);
  assert.deepEqual(source,original);
});

test('workspace chat sidebars treat bare lowercase direct-message handles as usernames',()=>{
 const data=ocr([row('Tidewater Robotics',20,20),row('CHANNELS',20,110),row('95 members',1100,25),row('farah',70,340,65,26),row('Hello there',652,199),row('Message #marketing',560,1540)]);
 const result=analyzeChat(data,2560,1600,1,{dividers:[520]});
 assert.equal(result.detected,true);assert.ok(result.findings.some(f=>f.kind==='username'&&f.x<100&&f.y>300));
});

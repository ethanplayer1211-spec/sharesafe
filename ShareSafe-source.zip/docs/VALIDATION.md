Validation · 16 November 2026 (Malaysia)

Verified

- JavaScript syntax checks pass. Seven Node tests pass for normalized drag geometry, outward pixel coverage, bounded move/resize, independent bounded undo snapshots, export paint order, opaque color enforcement and safe PNG filenames.
- Local browser: example loads; PNG file chooser import resets history; drag draws a solid cover; selecting/moving and corner resizing work; undo/redo restore changes; custom cover colors and numbered pins work; replacement warns about unexported edits.
- Export requires the review checkbox. An actual browser export of the unchanged example was downloaded and independently decoded. Result: 1280 × 800, all 9,894 cover-region pixels equal opaque RGB (32, 37, 43), and only IHDR/IDAT/IEND chunks (no text or EXIF).
- Editor console contained no warnings/errors during the checked desktop interactions.
- The 390 × 844 responsive breakpoint has no horizontal page overflow. Tools, zoom and export remain available. Adding a numbered pin and deleting it through the toolbar were checked in that layout.
- A layout regression discovered during QA was fixed: the workspace has a stable height and an independently scrolling sidebar so adding edit rows does not shift the image mid-drag. Pointer-up also consumes its final coordinates.

Limits

- Manual privacy review, not automatic detection. OCR and AI scanning are absent.
- Physical phone/touch hardware, Safari/Firefox, native clipboard image paste and OS drag-and-drop have not been independently exercised. Their event handlers are implemented; browser checks used pointer input and the file chooser.
- Session edits are memory-only. Browser/device memory and canvas limits still apply to large images.
- No guarantee against user mistakes, uncovered details, saved originals or captures of the comparison view.

The portable HTML build uses the same application code and example image, bundled without external assets and with Content Security Policy hashes for its inline code and styles. Its JavaScript syntax is checked during generation. The automation browser blocks local file URLs, so direct file-opening was not independently exercised there.

Validation · 16 November 2026 (Malaysia)

Verified

- JavaScript syntax checks pass. Seven Node tests pass for normalized drag geometry, outward pixel coverage, bounded move/resize, independent bounded undo snapshots, export paint order, opaque color enforcement and safe PNG filenames.
- Local browser: example loads; PNG file chooser import resets history; drag draws a solid cover; selecting/moving and corner resizing work; undo/redo restore changes; custom cover colors and numbered pins work; replacement warns about unexported edits.
- Export requires the review checkbox. An actual browser export of the unchanged example was downloaded and independently decoded. Result: 1280 × 800, all 9,894 cover-region pixels equal opaque RGB (32, 37, 43), and only IHDR/IDAT/IEND chunks (no text or EXIF).
- Editor console contained no warnings/errors during the checked desktop interactions.
- The 390 × 844 responsive breakpoint has no horizontal page overflow. Tools, zoom and export remain available. Adding a numbered pin and deleting it through the toolbar were checked in that layout.
- A layout regression discovered during QA was fixed: the workspace has a stable height and an independently scrolling sidebar so adding edit rows does not shift the image mid-drag. Pointer-up also consumes its final coordinates.

Limits

- Manual privacy review, not automatic detection. OCR and AI scanning are absent.
- Physical phone/touch hardware, Safari/Firefox, native clipboard image paste and OS drag-and-drop have not been independently exercised. Their event handlers are implemented; browser checks used pointer input and the file chooser.
- Session edits are memory-only. Browser/device memory and canvas limits still apply to large images.
- No guarantee against user mistakes, uncovered details, saved originals or captures of the comparison view.

Offline-entry correction

- A user reported that opening `dist/index.html` directly from disk left all controls inactive. That entry still referenced external JavaScript modules, which browsers block under local file origins.
- `src/editor.html` is now the source template. The builder produces identical self-contained `ShareSafe.html`, `dist/index.html` and `release/ShareSafe.html` files. All CSS, application code and the example image are embedded. A classic script at the end of the body initializes inside a private closure.
- Two additional regression tests verify that the default entry has no external modules/styles, contains its controls before initialization, parses successfully, and matches its CSP hashes after newline normalization. Total: nine tests.
- Direct file URLs are blocked by the automation browser. Browser workflow checks use the exact generated default HTML through a loopback preview; direct-file confirmation in the user's browser remains a separate check.
- The generated entry passed browser checks for opening Help, importing a PNG, drawing a cover, adding a numbered pin, undo/redo, reviewing export, and downloading a 1280 × 800 PNG. The browser console contained no warnings/errors during startup/import.

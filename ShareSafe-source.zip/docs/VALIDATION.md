Validation · 16 November 2026 (Malaysia)

Automatic detection · v1.1.0

- Thirteen Node tests and all four JavaScript syntax checks pass. New cases cover structured-detail matching, invalid cards/dates, OCR word boxes mapped to source pixels, clamping, and labels split across OCR blocks.
- Real browser scan of the original 1280 × 800 bundled inbox found its email and private workspace code. The example now starts without pre-applied edits. Review, select/deselect all, apply both as one undo step, undo and redo were exercised.
- A separate 1360 × 650 PNG rendered by `tools/make-scan-fixture.ps1` contained six fictional private details and an ordinary meeting date/time. Import started scanning automatically. It found exactly the email, phone, IPv4 address, Luhn-valid card, API key and private workspace code; no date/time suggestion. Deselecting the phone applied five covers and left one pending suggestion. This is a small controlled fixture, not a general accuracy measurement.
- Cancel during worker initialization stopped the scan. Switching back to the example cleared the old results/history; no late result replaced the current image. Workers are terminated and Blob URLs revoked in success, error and abort cleanup.
- English model bytes and the SIMD LSTM WASM engine are bundled in the HTML. The browser scan ran under `connect-src 'none'`, using a Blob worker, without console warnings/errors. Language bytes are passed directly into the worker with cache disabled, rather than fetched from a CDN.
- Actual browser exports before/after applying the two OCR covers were independently PNG-decoded by `tools/verify-ocr-export.mjs`: 1280 × 800, 4,510 changed pixels confined to the email/code regions, all opaque RGB (32,37,43). Only IHDR/IDAT/IEND chunks. Dashed suggestion outlines/numbers were absent from export. The pending-suggestion warning and manual review checkbox were checked.
- At the 390 × 844 phone breakpoint, the page had no horizontal overflow. The review dialog remained readable and applying both suggested covers worked. This used desktop browser viewport emulation, not physical touch hardware.
- Screenshots: `.runtime/qa/ocr-six-details.jpg`, `ocr-suggestions.jpg`, `ocr-applied.jpg`, `ocr-mobile.jpg`. Original/covered PNGs: `ocr-example-original.png`, `ocr-example-covered.png`.

Current limitations

- Requires a current browser with WebAssembly SIMD and Blob worker support. Recognition is English OCR plus structured pattern checks. Names, postal addresses, faces, QR codes and arbitrary private messages need manual review/covers. Small, rotated, low-contrast or unusual text may be missed or misread.
- Direct file URLs remain unavailable to the automation browser. The exact generated self-contained entry was tested through ordinary loopback HTTP. The user's own direct-file browser check is still separate; no claim of having exercised it is made here.
- No physical-device touch, Safari/Firefox, native image clipboard paste or OS drag-and-drop verification in this pass.

Earlier manual-editor validation (before v1.1)

Verified

- JavaScript syntax checks pass. Seven Node tests pass for normalized drag geometry, outward pixel coverage, bounded move/resize, independent bounded undo snapshots, export paint order, opaque color enforcement and safe PNG filenames.
- Local browser: example loads; PNG file chooser import resets history; drag draws a solid cover; selecting/moving and corner resizing work; undo/redo restore changes; custom cover colors and numbered pins work; replacement warns about unexported edits.
- Export requires the review checkbox. An actual browser export of the unchanged example was downloaded and independently decoded. Result: 1280 × 800, all 9,894 cover-region pixels equal opaque RGB (32, 37, 43), and only IHDR/IDAT/IEND chunks (no text or EXIF).
- Editor console contained no warnings/errors during the checked desktop interactions.
- The 390 × 844 responsive breakpoint has no horizontal page overflow. Tools, zoom and export remain available. Adding a numbered pin and deleting it through the toolbar were checked in that layout.
- A layout regression discovered during QA was fixed: the workspace has a stable height and an independently scrolling sidebar so adding edit rows does not shift the image mid-drag. Pointer-up also consumes its final coordinates.

Limits

- These earlier checks predate the v1.1 OCR scanner documented above.
- Physical phone/touch hardware, Safari/Firefox, native clipboard image paste and OS drag-and-drop have not been independently exercised. Their event handlers are implemented; browser checks used pointer input and the file chooser.
- Session edits are memory-only. Browser/device memory and canvas limits still apply to large images.
- No guarantee against user mistakes, uncovered details, saved originals or captures of the comparison view.

Offline-entry correction

- A user reported that opening `dist/index.html` directly from disk left all controls inactive. That entry still referenced external JavaScript modules, which browsers block under local file origins.
- `src/editor.html` is now the source template. The builder produces identical self-contained `ShareSafe.html`, `dist/index.html` and `release/ShareSafe.html` files. All CSS, application code and the example image are embedded. A classic script at the end of the body initializes inside a private closure.
- Two additional regression tests verify that the default entry has no external modules/styles, contains its controls before initialization, parses successfully, and matches its CSP hashes after newline normalization. Total: nine tests.
- Direct file URLs are blocked by the automation browser. Browser workflow checks use the exact generated default HTML through a loopback preview; direct-file confirmation in the user's browser remains a separate check.
- The generated entry passed browser checks for opening Help, importing a PNG, drawing a cover, adding a numbered pin, undo/redo, reviewing export, and downloading a 1280 × 800 PNG. The browser console contained no warnings/errors during startup/import.

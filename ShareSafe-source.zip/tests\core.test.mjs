import test from 'node:test';
import assert from 'node:assert/strict';
import { boxFromPoints, opaqueBounds, moveShape, resizeShape, EditHistory, drawComposite, COLORS, exportFilename } from '../dist/core.js';

test('backwards and out-of-bounds drags normalize to the image', () => {
  assert.deepEqual(boxFromPoints({x:90,y:80},{x:-20,y:10},100,60),{x:0,y:10,w:90,h:50});
  assert.deepEqual(boxFromPoints({x:120,y:70},{x:110,y:90},100,60),{x:100,y:60,w:0,h:0});
});

test('covers round outwards and cover every touched pixel, including fractional edges', () => {
  assert.deepEqual(opaqueBounds({x:10.8,y:12.9,w:3.3,h:2.3},100,100),{x:10,y:12,w:5,h:4});
  assert.deepEqual(opaqueBounds({x:99.8,y:99.8,w:20,h:20},100,100),{x:99,y:99,w:1,h:1});
});

test('move and corner resize keep covers within the image, even crossing the opposite corner', () => {
  const shape = {type:'redact',x:10,y:10,w:30,h:20};
  assert.deepEqual(moveShape(shape,-50,200,100,80),{...shape,x:0,y:60});
  assert.deepEqual(resizeShape(shape,'nw',{x:70,y:60},100,80),{...shape,x:40,y:30,w:30,h:30});
  assert.deepEqual(moveShape({type:'marker',x:10,y:10},200,-50,100,80),{type:'marker',x:100,y:0});
});

test('undo/redo uses independent snapshots, discards branches, and keeps a bounded history', () => {
  const history = new EditHistory();
  const first = [{id:1,x:10}]; history.commit(first); first[0].x=90;
  assert.equal(history.current[0].x,10);
  history.commit([{id:1,x:20}]); assert.equal(history.undo()[0].x,10);
  assert.equal(history.redo()[0].x,20);
  history.undo(); history.commit([{id:2,x:30}]); assert.equal(history.canRedo,false);
  const current = history.current; current[0].x=999; assert.equal(history.current[0].x,30);
  for(let i=0;i<100;i++) history.commit([{x:i}]);
  assert.equal(history.entries.length,61);
  history.reset(); assert.deepEqual(history.current,[]); assert.equal(history.canUndo,false);
});

test('export paints opaque cover pixels after original image, with no editor selection or history', () => {
  const calls=[];
  const ctx={save(){},restore(){},fillRect(...args){calls.push({type:'fill',args,color:this.fillStyle,alpha:this.globalAlpha,mode:this.globalCompositeOperation});},drawImage(...args){calls.push({type:'image',args});}};
  drawComposite(ctx, 'original', [{type:'redact',x:10.4,y:20.2,w:14.7,h:12.5,style:'black'}],100,80);
  assert.equal(calls[0].color,'#ffffff'); assert.equal(calls[1].type,'image');
  assert.deepEqual(calls[2],{type:'fill',args:[10,20,16,13],color:COLORS.ink,alpha:1,mode:'source-over'});
  assert.equal(calls.length,3);
});

test('unapproved cover colors fall back to opaque ink', () => {
  const colors=[];
  const ctx={save(){},restore(){},drawImage(){},fillRect(){colors.push(this.fillStyle);}};
  drawComposite(ctx, {}, [{type:'redact',x:0,y:0,w:10,h:10,color:'rgba(0,0,0,0)'}],100,100);
  assert.equal(colors.at(-1),COLORS.ink);
});

test('export filenames have a PNG extension without path components or original metadata', () => {
  assert.equal(exportFilename('my-shot.jpg'),'my-shot-sharesafe.png');
  assert.equal(exportFilename('../../secret<script>.webp'),'secretscript-sharesafe.png');
  assert.equal(exportFilename('😀.png'),'screenshot-sharesafe.png');
});

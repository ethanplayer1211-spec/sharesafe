import assert from 'node:assert/strict';import {decode} from './verify-ocr-export.mjs';import {readFile,writeFile} from 'node:fs/promises';
const root=process.argv[2]||'docs/review-five',selection=JSON.parse(await readFile(root+'/selection.json','utf8')),boxes=JSON.parse(await readFile(root+'/review-regions.json','utf8')),keys=Object.keys(boxes);let report=[];
for(let i=0;i<5;i++){
 const key=keys[i],source=await decode(root+'/'+key+'-original.png'),black=await decode(root+'/'+key+'-black.png'),blur=await decode(root+'/'+key+'-blur.png');
 assert.equal(source.width,black.width);assert.equal(source.height,black.height);assert.equal(source.width,blur.width);assert.equal(source.height,blur.height);
 let unchangedOutside=0,blackPixelsChanged=0,blurPixelsChanged=0;
 for(let p=0;p<source.width*source.height;p++){
 const a=p*source.channels,b=p*black.channels,c=p*blur.channels;const original=[...source.pixels.subarray(a,a+3)],redacted=[...black.pixels.subarray(b,b+3)],soft=[...blur.pixels.subarray(c,c+3)];
 if(black.channels===4)assert.equal(black.pixels[b+3],255);if(blur.channels===4)assert.equal(blur.pixels[c+3],255);
 if(redacted.some((v,j)=>v!==original[j])){assert.deepEqual(redacted,[0,0,0]);blackPixelsChanged++;}
 if(redacted.some(v=>v!==0)){assert.deepEqual(soft,original,'Blur changed a pixel outside its black-mask counterpart at '+key+':'+p);unchangedOutside++;}
 if(soft.some((v,j)=>v!==original[j]))blurPixelsChanged++;
 }
 assert.ok(blackPixelsChanged>1000);assert.ok(blurPixelsChanged>1000);assert.ok(unchangedOutside>source.width*source.height*.8);
 const item={case:key,blackPixelsChanged,blurPixelsChanged,unchangedOutside,width:source.width,height:source.height,blackChunks:[...new Set(black.chunks)],blurChunks:[...new Set(blur.chunks)]};report.push(item);
 console.log(JSON.stringify(item));
}
await writeFile(root+'/export-integrity.json',JSON.stringify({success:true,cases:report},null,2));


import { readFile, writeFile } from 'node:fs/promises';
const entries = [
  ['Compromise 14.20.0 (local English name recognition)', 'node_modules/compromise/LICENSE'],
  ['efrt (included by Compromise)', 'node_modules/efrt/LICENSE'],
  ['suffix-thumb (included by Compromise)', 'node_modules/suffix-thumb/LICENSE'],
  ['Tesseract.js 7.0.0 (unmodified bundled browser worker)', 'node_modules/tesseract.js/LICENSE.md'],
  ['Tesseract.js-core 7.0.0 (unmodified SIMD LSTM WebAssembly engine)', 'node_modules/tesseract.js-core/LICENSE'],
  ['Notices preserved from the bundled worker', 'node_modules/tesseract.js/dist/worker.min.js.LICENSE.txt'],
  ['bmp-js', 'node_modules/bmp-js/LICENSE'],
  ['idb-keyval (cache disabled in ShareSafe)', 'node_modules/idb-keyval/LICENCE'],
  ['is-url', 'node_modules/is-url/LICENSE-MIT'],
  ['regenerator-runtime', 'node_modules/regenerator-runtime/LICENSE'],
  ['wasm-feature-detect', 'node_modules/wasm-feature-detect/LICENSE'],
  ['zlibjs', 'node_modules/zlibjs/LICENSE']
];
let text = 'ShareSafe third-party notices\n\nShareSafe application code is MIT licensed. The application bundles the existing Tesseract OCR engine and English model; we did not train them. The upstream JavaScript and WASM bundles are unmodified, wrapped by our local worker adapter.\n\nEnglish traineddata: @tesseract.js-data/eng 1.0.0, 4.0.0_best_int/eng.traineddata.gz. Package metadata declares MIT; the underlying naptha/tessdata language-data repository is Apache-2.0 licensed (Apache license text below).\nSources: https://github.com/naptha/tesseract.js, https://github.com/naptha/tesseract.js-core, https://github.com/naptha/tessdata\n\n';
for (const [name,path] of entries) text += `${name}\n${'='.repeat(name.length)}\n${await readFile(path,'utf8')}\n\n`;
// Additional MIT/BSD browser shims are included in the upstream worker bundle.
text += 'Buffer browser shim: Copyright (c) Feross Aboukhadijeh and contributors. MIT license (permission and disclaimer as reproduced above).\nIEEE754 browser shim: Copyright (c) Feross Aboukhadijeh and contributors. BSD-3-Clause:\nRedistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:\n1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.\n2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.\n3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.\nTHIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.\n';
text += '\nReview/demo screenshot data: Beaumont, Louis (2026). ScreenLeak. https://github.com/screenpipe/screenleak\nCC BY 4.0: https://creativecommons.org/licenses/by/4.0/\nFive source screenshots are synthetic. Modified copies were censored with ShareSafe. License and provenance: docs/review-five/. These review images are separate from the bundled editor examples.\n';
await writeFile('THIRD_PARTY_NOTICES.txt',text);

$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Drawing
$taskRoot=Split-Path $PSScriptRoot -Parent
$taskCases=@(
 @{Name='1  Arc';File='01-arc-black.png';Crop=[Drawing.Rectangle]::new(0,0,1730,530)},
 @{Name='2  Slack';File='02-slack-black.png';Crop=[Drawing.Rectangle]::new(0,0,1530,520)},
 @{Name='3  GitHub';File='03-github-black.png';Crop=[Drawing.Rectangle]::new(0,0,2880,500)},
 @{Name='4  Terminal';File='04-terminal-black.png';Crop=[Drawing.Rectangle]::new(0,0,1000,180)},
 @{Name='5  Cursor';File='05-cursor-black.png';Crop=[Drawing.Rectangle]::new(0,0,900,200)}
)
$taskFont=[Drawing.Font]::new('Segoe UI',28,[Drawing.FontStyle]::Bold,[Drawing.GraphicsUnit]::Pixel)
$taskBrush=[Drawing.SolidBrush]::new([Drawing.ColorTranslator]::FromHtml('#293226'))
$taskCanvas=[Drawing.Bitmap]::new(2400,1040);$taskG=[Drawing.Graphics]::FromImage($taskCanvas);$taskG.Clear([Drawing.ColorTranslator]::FromHtml('#f6f5f1'))
$taskG.InterpolationMode=[Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
for($taskI=0;$taskI -lt $taskCases.Count;$taskI++){
 $taskCase=$taskCases[$taskI];$taskX=($taskI%3)*800+20;$taskY=[Math]::Floor($taskI/3)*500+20
 $taskG.DrawString($taskCase.Name,$taskFont,$taskBrush,$taskX,$taskY)
 $taskImage=[Drawing.Image]::FromFile((Join-Path $taskRoot ('docs\review-five\'+$taskCase.File)))
 $taskScale=[Math]::Min(750.0/$taskCase.Crop.Width,390.0/$taskCase.Crop.Height)
 $taskG.DrawImage($taskImage,[Drawing.Rectangle]::new($taskX,$taskY+55,[int]($taskCase.Crop.Width*$taskScale),[int]($taskCase.Crop.Height*$taskScale)),$taskCase.Crop,[Drawing.GraphicsUnit]::Pixel)
 $taskImage.Dispose()
}
$taskCanvas.Save((Join-Path $taskRoot 'docs\media\five-tested.png'),[Drawing.Imaging.ImageFormat]::Png)
$taskG.Dispose();$taskCanvas.Dispose()
$taskCanvas=[Drawing.Bitmap]::new(1000,520);$taskG=[Drawing.Graphics]::FromImage($taskCanvas);$taskG.Clear([Drawing.ColorTranslator]::FromHtml('#f6f5f1'))
$taskG.DrawString('Original',$taskFont,$taskBrush,20,20);$taskG.DrawString('Reviewed export',$taskFont,$taskBrush,520,20)
foreach($taskMode in @('original','black')){
 $taskX=20;if($taskMode -eq 'black'){$taskX=520}
 $taskImage=[Drawing.Image]::FromFile((Join-Path $taskRoot ('docs\review-five\03-github-'+$taskMode+'.png')))
 $taskG.DrawImage($taskImage,[Drawing.Rectangle]::new($taskX,90,460,300),[Drawing.Rectangle]::new(2310,155,410,270),[Drawing.GraphicsUnit]::Pixel);$taskImage.Dispose()
}
$taskCanvas.Save((Join-Path $taskRoot 'docs\media\github-review-detail.png'),[Drawing.Imaging.ImageFormat]::Png)
$taskG.Dispose();$taskCanvas.Dispose();$taskFont.Dispose();$taskBrush.Dispose()

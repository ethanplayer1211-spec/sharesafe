import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {decode} from './verify-ocr-export.mjs';
const root=process.argv[2]||'docs/review-five';
const regions={
 '01-arc':[[190,50,218,34],[608,112,560,86],[92,256,122,34],[233,256,162,34],[92,322,219,34],[216,454,167,34],[834,320,180,36],[1110,320,450,36]],
 '02-slack':[[24,28,472,49],[601,28,153,49],[652,155,175,44],[652,276,167,44],[652,397,190,44],[845,199,585,42],[652,320,74,42],[652,441,330,42],[560,156,72,72],[560,276,72,72],[560,398,72,72],[69,340,65,26]],
 '03-github':[[40,24,294,32],[56,160,168,34],[102,240,157,32],[102,437,145,32],[2414,208,158,34],[2414,259,179,34],[2358,198,40,40],[2358,250,40,40]],
 '04-terminal':[[574,48,202,16],[220,109,421,16],[550,8,80,14],[18,48,145,16],[171,48,168,16],[338,88,255,16]],
 '05-cursor':[[393,65,180,15],[424,106,110,15],[440,148,274,15],[20,38,149,15],[114,747,154,15]]
};
await writeFile(root+'/review-regions.json',JSON.stringify(regions,null,2));
const report=[];
for (let [key,boxes] of Object.entries(regions)){
 let files={'01-arc':'01-arc-original.png','02-slack':'02-slack-original.png','03-github':'03-github-original.png','04-terminal':'04-terminal-original.png','05-cursor':'05-cursor-original.png'};
 let before=await decode(root+'/'+files[key]),after;try{after=await decode(root+'/'+key+'-black.png')}catch{continue;}
 let result=[];
 for(let [x,y,w,h]of boxes){
 const bins=new Map();for(let yy=y;yy<y+h;yy++)for(let xx=x;xx<x+w;xx++){let i=(yy*before.width+xx)*before.channels,k=[...before.pixels.subarray(i,i+3)].join(',');bins.set(k,(bins.get(k)||0)+1);}
 const bg=[...bins].sort((a,b)=>b[1]-a[1])[0][0].split(',').map(Number);let ink=0,left=0,bounds=[1e9,1e9,0,0];
 for(let yy=y;yy<y+h;yy++)for(let xx=x;xx<x+w;xx++){let a=(yy*before.width+xx)*before.channels,b=(yy*after.width+xx)*after.channels;if([0,1,2].reduce((s,c)=>s+Math.abs(before.pixels[a+c]-bg[c]),0)<90)continue;ink++;if([0,1,2].some(c=>after.pixels[b+c]!==0)){left++;bounds=[Math.min(bounds[0],xx),Math.min(bounds[1],yy),Math.max(bounds[2],xx),Math.max(bounds[3],yy)];}}
 result.push({box:[x,y,w,h],ink,left,bounds:left?bounds:null});
 }
 assert.equal(after.width,before.width);assert.equal(after.height,before.height);
 console.log(key,JSON.stringify(result.filter(r=>r.left))); assert.ok(result.every(r=>r.left===0),key+' leaves private detail pixels');
 report.push({case:key,width:after.width,height:after.height,regions:result,metadataChunks:[...new Set(after.chunks)]});
}


await writeFile(root+'/coverage-report.json',JSON.stringify({success:true,scope:'Marked visible sensitive values, excluding labels, separators and ellipses. Synthetic examples; reviewed workflow includes manual corrections.',cases:report},null,2));
console.log(JSON.stringify({success:true,cases:report.length,regions:report.reduce((n,r)=>n+r.regions.length,0),privatePixelsVerified:report.reduce((n,r)=>n+r.regions.reduce((a,b)=>a+b.ink,0),0)}));


Validation · 16 November 2026 (Malaysia)

Current release · v1.4.0

- Replaced clean fill and colored covers with two styles: true opaque black by default, and fixed strong canvas blur. Style changes apply to all covers and support undo/redo; unsupported filter contexts fall back to black.
- Added original-color OCR alongside contrast normalization; overlapping same-kind matches merge outward. Scan surface cap is eight megapixels. Added reviewable work-detail matching, more credential formats, terminal identities/home paths, and workspace-chat sidebar handle matching. Lowercase ordinary words are not accepted as single unlabelled names.
- Thirty-one unit/regression tests and six syntax checks passed. Browser tests verified import auto-scan, preview cancellation with zero edits, applying 20 DM covers, undo to zero, redo to 20, global style changes, and style controls following undo/redo. Warning/error console logs were empty for the checked page.
- Independent selection: ScreenLeak public synthetic corpus commit 3670788846e99a64ae93128c0fa97f180f5825f6, seed 8508867, random app-type selection then one file per type, frozen before OCR. The five cases are Arc, Slack, GitHub, Terminal and Cursor. Source data is CC BY 4.0 and fictional. Provenance/license live in docs/review-five/.
- All five reviewed examples were explicitly approved by the user: “Approve all five examples”. Approval recorded in docs/review-five/approval.json. It does not authorize a YouTube upload.
- Manual review mattered: GitHub had one false name suggestion rejected and a rectangle added over profile icons; Cursor needed a rectangle over the status-bar workspace path. The remaining three needed no additional manual rectangles with all filters enabled. This does not establish category-specific recall; one Slack avatar is inside a message suggestion as well.
- Downloaded black PNGs passed source-resolution checks over 39 marked private-value regions / 82,326 visible private pixels. Whole-page annotation boxes were narrowed to visible values and exclude labels/separators/ellipses. No claim of a full benchmark score is made.
- For each of five black/blur pairs, source dimensions match, pixels are opaque, all black-export changes are black, and blur pixels outside the corresponding black masks remain identical to the source. PNG chunks: IHDR/IDAT/IEND. See coverage-report.json and export-integrity.json.
- The DM regression black export passed the 18 existing text/photo region checks; 1,017,398 pixels outside allowed cover areas stayed identical. Original, black and blur examples are in docs/media/.
- The final narrated demo is H.264/AAC, 1920×1080, 30 fps, 1,905 frames, 63.5 seconds, with a synthetic English male voice (en-US-AndrewNeural). It has 26 timed captions, burned in and also available as a subtitle track and SRT. Full decode completed without errors and extracted frames were visually inspected for text/layout. Audio peaks at -1.5 dB; mean volume is -16.9 dB. TTS word metadata matches the script, caption cues do not overlap, and all cues fall within the video. It includes actual app captures, exports, test scope, manual-correction disclosure. Production footer, slide counter and redundant image notes were removed at the user’s request; source credits remain in documentation and the video description.
- Direct file:// browser automation is blocked by browser policy. The exact generated HTML was tested through loopback HTTP; direct-file operation in the user's own browser was not independently automated.
- Remaining limits: English-focused OCR/NER, approximate avatar/photo boundaries, uncertain organizations/paths and cropped/unfamiliar layouts. Review the full exported PNG. Blur can retain clues; Black replaces covered pixels.

Historical validation follows; these older cover colors and test counts are superseded by v1.4.

Validation · 16 November 2026 (Malaysia)

DM accuracy and clean covers · v1.3.0

- User clarified the issue: desktop Instagram DM screenshots missed plain usernames, profile photos and message text; the image itself was not disappearing. The generic structured-pattern scan was insufficient for that layout.
- Added Auto / Chat-DMs / General modes, a message-text category, layout-based plain-handle matching, handle repeats in messages, circle-boundary checks for grayscale avatars, a manual conversation area, and column separation for OCR matches. Large themed backgrounds cannot become page-sized picture suggestions.
- Contrast normalization operates on an OCR-only copy. It recovers white text on colored bubbles; the original image is retained unchanged. Long normalization outlines are removed from that copy so Tesseract reads text within colored bubbles.
- Twenty-seven tests and six syntax checks pass. The actual Tesseract model is also checked by `tools/check-dm-scan.mjs` at one- and two-times scale on the fictional DM fixture. Controlled result: five username occurrences, eight message lines/previews and six grayscale avatars. These are fixtures, not a general accuracy benchmark.
- Live browser result: twenty suggestions (five usernames, eight message text regions, six profile photos, one overlapping structured address). The prior false positive on the OCR-misread Messages heading was corrected. Generic picture estimates and inferred unlabelled names now start unchecked.
- Preview expands the editing canvas without creating applied edits. Adjusting a pending cover through a corner handle and cancelling left the applied edit count at zero. Applying the batch, undoing it to zero and redoing were verified.
- Setting General mode suppressed chat detection. Dragging a custom conversation area switched to Chat/DM mode without creating edits and reduced message suggestions from eight (including list previews) to the five conversation lines inside that area. At 390 × 844, the review dialog and expanded preview had no horizontal overflow; cancelling preview still left zero applied edits. No browser warning/error logs were captured in this pass.
- The downloaded 1360 × 860 PNG passed `tools/verify-dm-export.mjs`. All tested username/message glyph pixels and all non-background pixels in all six avatar regions were replaced by the expected fully opaque flat fills (#0c0c0c, #262626, #6651dc). The 1,017,398 pixels outside the allowed cover areas stayed identical to the source. PNG chunks were IHDR/IDAT/IEND only.
- Evidence: `.runtime/qa/dm-clean-preview.jpg`, `dm-export.png`, `dm-export-verification.json`, `dm-scan.json`. Only fictional example details were used. The user's actual Instagram screenshot has not been supplied or tested.
- Limits: English OCR, screenshot-layout and circle-boundary heuristics can still miss content. Cropped or unfamiliar chat layouts, non-English messages, emojis and image messages may need manual covers or a custom conversation area. Clean fill needs a sufficiently uniform surrounding surface; otherwise it uses opaque ink. Review the whole export.

Privacy filters · v1.2.0

- Twenty tests and five syntax checks pass. Added coverage includes actual Compromise name recognition, Unicode labeled names, usernames, labeled birthdays and invalid numeric dates, addresses/IDs, independent filter categories, custom phrases with punctuation/overlap, OCR avatar punctuation, image-region coordinates, and rejection of ordinary text/blank panels as pictures.
- Ten filter categories update cached suggestions immediately without another OCR pass: names, usernames, birthdays, personal info, profile photos, pictures, contact details, credentials, payment cards and IPs. Counts and grouped thumbnail review were checked in the browser.
- The fictional 1360 × 860 filter example produced eleven suggestions: two name occurrences, a username, birthday, address, student ID, email, phone, credential, picture and illustrated profile avatar. The ordinary meeting date/time was not flagged. This deliberately controlled fixture is not a general accuracy benchmark or a test on real personal photos.
- Disabling all filters and adding the exact phrase “Fictional creator profile” left one custom-word suggestion. Clearing that phrase and enabling only birthdays, pictures and profile photos left exactly those three suggestions. All changes used cached OCR results.
- Applying those three suggestions created three covers. Disabling all categories retained all three applied covers. Undo removed the batch; redo restored it. Re-enabling all categories left eight additional suggestions, and applying them produced eleven covers.
- Downloaded the actual browser export. `tools/verify-filter-export.ps1` independently checked all 6,400 avatar pixels and 70,400 picture pixels, plus 770 username glyph pixels, 943 birthday glyph pixels, 1,409 address glyph pixels and 484 student-ID glyph pixels: all opaque RGB (32,37,43). Dimensions remained 1360 × 860. Evidence is in `.runtime/qa/filter-export.png` and `filter-export-verification.json`.
- At a 390 × 844 viewport, both the page and filter dialog had matching client/scroll widths (no horizontal overflow); the Done control remained usable in the scrolling dialog. Desktop console checks contained no warnings/errors.
- The second example and Compromise library are embedded in the standalone HTML. All three delivered HTML entries remain identical. No screenshot, OCR text, custom words or name/photo analysis is sent to a server or saved in browser storage.
- Picture/profile-photo detection estimates connected color/texture regions and uses nearby name/username context for avatar-like regions. It does not identify people. It can miss photos, mistake icons or artwork for photos, or suggest an incomplete region; every edge needs review and may need manual resizing. Name recognition is English-focused; birth dates and many personal fields need labels. QR codes and arbitrary private messages remain outside reliable automatic coverage.
- UI evidence: `.runtime/qa/privacy-filters.jpg`, `privacy-filters-mobile.jpg`, `filter-selected-results.jpg`, `filters-applied.jpg`. The bundled example is generated by `tools/make-filter-fixture.ps1`; its source artwork and details are fictional.

Automatic detection · v1.1.0

- Thirteen Node tests and all four JavaScript syntax checks pass. New cases cover structured-detail matching, invalid cards/dates, OCR word boxes mapped to source pixels, clamping, and labels split across OCR blocks.
- Real browser scan of the original 1280 × 800 bundled inbox found its email and private workspace code. The example now starts without pre-applied edits. Review, select/deselect all, apply both as one undo step, undo and redo were exercised.
- A separate 1360 × 650 PNG rendered by `tools/make-scan-fixture.ps1` contained six fictional private details and an ordinary meeting date/time. Import started scanning automatically. It found exactly the email, phone, IPv4 address, Luhn-valid card, API key and private workspace code; no date/time suggestion. Deselecting the phone applied five covers and left one pending suggestion. This is a small controlled fixture, not a general accuracy measurement.
- Cancel during worker initialization stopped the scan. Switching back to the example cleared the old results/history; no late result replaced the current image. Workers are terminated and Blob URLs revoked in success, error and abort cleanup.
- English model bytes and the SIMD LSTM WASM engine are bundled in the HTML. The browser scan ran under `connect-src 'none'`, using a Blob worker, without console warnings/errors. Language bytes are passed directly into the worker with cache disabled, rather than fetched from a CDN.
- Actual browser exports before/after applying the two OCR covers were independently PNG-decoded by `tools/verify-ocr-export.mjs`: 1280 × 800, 4,510 changed pixels confined to the email/code regions, all opaque RGB (32,37,43). Only IHDR/IDAT/IEND chunks. Dashed suggestion outlines/numbers were absent from export. The pending-suggestion warning and manual review checkbox were checked.
- At the 390 × 844 phone breakpoint, the page had no horizontal overflow. The review dialog remained readable and applying both suggested covers worked. This used desktop browser viewport emulation, not physical touch hardware.
- Screenshots: `.runtime/qa/ocr-six-details.jpg`, `ocr-suggestions.jpg`, `ocr-applied.jpg`, `ocr-mobile.jpg`. Original/covered PNGs: `ocr-example-original.png`, `ocr-example-covered.png`.

Current limitations

- Requires a current browser with WebAssembly SIMD and Blob worker support. Recognition is English OCR plus structured pattern checks. Names, postal addresses, faces, QR codes and arbitrary private messages need manual review/covers. Small, rotated, low-contrast or unusual text may be missed or misread.
- Direct file URLs remain unavailable to the automation browser. The exact generated self-contained entry was tested through ordinary loopback HTTP. The user's own direct-file browser check is still separate; no claim of having exercised it is made here.
- No physical-device touch, Safari/Firefox, native image clipboard paste or OS drag-and-drop verification in this pass.

Earlier manual-editor validation (before v1.1)

Verified

- JavaScript syntax checks pass. Seven Node tests pass for normalized drag geometry, outward pixel coverage, bounded move/resize, independent bounded undo snapshots, export paint order, opaque color enforcement and safe PNG filenames.
- Local browser: example loads; PNG file chooser import resets history; drag draws a solid cover; selecting/moving and corner resizing work; undo/redo restore changes; custom cover colors and numbered pins work; replacement warns about unexported edits.
- Export requires the review checkbox. An actual browser export of the unchanged example was downloaded and independently decoded. Result: 1280 × 800, all 9,894 cover-region pixels equal opaque RGB (32, 37, 43), and only IHDR/IDAT/IEND chunks (no text or EXIF).
- Editor console contained no warnings/errors during the checked desktop interactions.
- The 390 × 844 responsive breakpoint has no horizontal page overflow. Tools, zoom and export remain available. Adding a numbered pin and deleting it through the toolbar were checked in that layout.
- A layout regression discovered during QA was fixed: the workspace has a stable height and an independently scrolling sidebar so adding edit rows does not shift the image mid-drag. Pointer-up also consumes its final coordinates.

Limits

- These earlier checks predate the v1.1 OCR scanner documented above.
- Physical phone/touch hardware, Safari/Firefox, native clipboard image paste and OS drag-and-drop have not been independently exercised. Their event handlers are implemented; browser checks used pointer input and the file chooser.
- Session edits are memory-only. Browser/device memory and canvas limits still apply to large images.
- No guarantee against user mistakes, uncovered details, saved originals or captures of the comparison view.

Offline-entry correction

- A user reported that opening `dist/index.html` directly from disk left all controls inactive. That entry still referenced external JavaScript modules, which browsers block under local file origins.
- `src/editor.html` is now the source template. The builder produces identical self-contained `ShareSafe.html`, `dist/index.html` and `release/ShareSafe.html` files. All CSS, application code and the example image are embedded. A classic script at the end of the body initializes inside a private closure.
- Two additional regression tests verify that the default entry has no external modules/styles, contains its controls before initialization, parses successfully, and matches its CSP hashes after newline normalization. Total: nine tests.
- Direct file URLs are blocked by the automation browser. Browser workflow checks use the exact generated default HTML through a loopback preview; direct-file confirmation in the user's browser remains a separate check.
- The generated entry passed browser checks for opening Help, importing a PNG, drawing a cover, adding a numbered pin, undo/redo, reviewing export, and downloading a 1280 × 800 PNG. The browser console contained no warnings/errors during startup/import.
